<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Add Event</div>
                    <div class="panel-body">
                    <form class="form-horizontal add_event" action="<?=site_url('event/createEvent')?>" method="post" enctype = "multipart/form-data">
                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Event Name</label>
                            <input type="text" name= "event_name" class="form-control" placeholder="Enter Event Name" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Event Description</label>

                            <textarea class= "form-control" name="event_description" placeholder="Enter Event Description"></textarea>
                        </div>
                        </div>

                        <div class="form-group">
                            <label>Event Album</label>
                            <input type="file" name="event_album"  size="20" accept="video/*,image/*" />
                        </div>

                        <div class="form-group">
                            <label>Select User</label>
                              <div class="col-md-12 rgt">
                                <select class="form-control" id='userMultislct'  name="selected_users_id[]" multiple="multiple">

                                    <?php
foreach ($query as $val) {
	echo ' <option value="' . $val->id . '">' . $val->first_name . '</option>';
}
?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Start Event Date</label>
                            <input type="text" class="form-control" name="event_date" id="datepicker" placeholder="Select Event Date">
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>End Event Date</label>
                            <input type="text" class="form-control" name="end_event_date" id="datepicker_end" placeholder="Select Event Date">
                        </div>
                        </div>


                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Start Event Time</label>
                            <input type="text" name="start_time"  class="form-control roundTimeExample" placeholder="Select Start Event Time" required>
                        </div>
                        </div>
                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>End Event Time</label>
                            <input type="text" name="end_time" class="form-control roundTimeExample" placeholder="Select End Event Time" required>
                        </div>
                        </div>
                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
