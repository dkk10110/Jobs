<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Add Event</div>
                    <div class="panel-body">
                    <?php foreach ($query as $val) {
	?>
                    <form class="form-horizontal add_event" action="<?=site_url('event/updateEvent')?>" method="post" enctype = "multipart/form-data">

                         <input type="hidden" name="id" value="<?=!empty($val->id) ? $val->id : ''?>">

                       <div class="col-sm-6">
                        <div class="form-group">

                         <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>

                            <label>Event Name</label>
                            <input type="text" name= "event_name" value="<?php echo @$val->event_name; ?>" class="form-control" placeholder="Enter Event Name" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Event Description</label>

                            <textarea class= "form-control" name="event_description" placeholder="Enter Event Description" required><?php echo @$val->event_description; ?></textarea>
                        </div>
                        </div>

                        <div class="form-group">
                            <label>Event Album</label>
                            <input type="file" name="event_album"  size="20" accept="video/*,image/*" />
                        </div>

                        <div class="form-group">
                            <label>Select User</label>
                              <div class="col-md-12 rgt">
                              <?php
$users = array();
	foreach ($selectedUser as $key => $value) {
		array_push($users, $value['selected_users_id']);
	}

	?>
                                <select class="form-control" id='userMultislct'  name="selected_users_id[]" multiple="multiple">
                                <?php

	foreach ($user as $key => $uname) {

		if (in_array($uname->id, $users)) {

			echo '<option selected value="' . $uname->id . '">' . $uname->first_name . '</option>';
		} else {
			echo '<option  value="' . $uname->id . '">' . $uname->first_name . '</option>';
		}
		//$selectedUser
	}

	?>
                             </select>
                            </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="text" class="form-control" name="event_date" value="<?php echo @$val->event_date; ?>" id="datepicker" placeholder="Select Event Date">
                        </div>
                        </div>


                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>End Date</label>
                            <input type="text" class="form-control" name="end_event_date" value="<?php echo @$val->end_event_date; ?>" id="datepicker_end" placeholder="Select Event Date">
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Start Event Time</label>

                            <input type="text" name="start_time" value="<?php echo @$val->st_time; ?>" class="form-control roundTimeExample" placeholder="Select Start Event Time" required>
                        </div>
                        </div>
                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>End Event Time</label>
                            <input type="text" name="end_time" value="<?php echo @$val->ed_time; ?>" class="form-control roundTimeExample" placeholder="Select End Event Time" required>
                        </div>
                        </div>
                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                        <?php }?>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
