<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo @$event_name[0]['event_name']; ?></div>
                    <div class="panel-body">
                    <form class="form-horizontal add_event" action="<?=site_url('event/createChecklist')?>" method="post" enctype = "multipart/form-data">

                      <input type="hidden" name= "id" value="<?php echo $id; ?>" class="form-control" placeholder="Enter Checklist Name" required>

                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Checklist Name</label>

                            <input type="text" name= "checklist_name" class="form-control" placeholder="Enter Checklist Name" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Checklist Description</label>
                            <textarea class= "form-control" name="checklist_description" placeholder="Enter Event Description" required></textarea>
                        </div>
                        </div>


                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>


<?php $this->load->view('backend/admin/layouts/footer');?>
