<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Event List</h3>
                            <a href="<?php echo base_url(); ?>event/addevent" class="btn btn-default" style="float: right; margin-top: -40px;">Add Event</a>
                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Event Image</th>
                                            <th>Event Name</th>
                                            <th>Event Description</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Checklist</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php if (!empty($query)) {
	?>
                                        <?php $i = 1;foreach ($query as $val) {
		?>
                                        <tr>
                                          <td><?php echo $i++ ?></td>

                                           <td>
                                          <?php
$extension = pathinfo($val->event_album, PATHINFO_EXTENSION);
		$extensions_type = ['gif', 'jpg', 'png', 'jpeg'];
		$imguri = 'https://s3.amazonaws.com/handbook_albums/events_images/' . $val->event_album;
		$imgVideo = 'https://s3.amazonaws.com/handbook_albums/events_video/' . $val->event_album;
		$dummyimg = base_url() . 'uploads/user.jpg';
		?>

                                           <?php if (in_array($extension, $extensions_type)) {?>
                                            <?php if ($imguri != '') {?>
                                            <img src="<?php echo $imguri; ?>" width='60px' height='60px'>
                                            <?php } else {?>
                                            <img src="<?php echo $dummyimg; ?>" width='60px' height='60px'>
                                            <?php }?>
                                           <?php } else {?>
                                           <?php if ($imgVideo != '') {?>
                                             <video width="60px" height="60px" controls>
                                                <source src="<?php echo $imgVideo; ?>">
                                              </video>
                                              <?php } else {?>
                                             <img src="<?php echo $dummyimg; ?>" width='60px' height='60px'>
                                              <?php }?>
                                           <?php }?>

                                          </td>

                                          <td class="evtname"><a href="<?php echo base_url() . 'event/eventSelectedUsers/' . $val->id; ?>"><?php echo @$val->event_name; ?></a></td>


                                          <td><?php if (empty($val->event_description)) {echo "";} else {echo $val->event_description;}
		;?></td>



                                          <td><?php if (empty($val->event_date)) {echo "";} else {echo $val->event_date;}
		;?></td>
                                          <td><?php if (empty($val->end_event_date)) {echo "";} else {echo $val->end_event_date;}
		;?></td>
                                          <td><?php
$st_time = date("H:i:s", strtotime($val->start_time));
		echo @$st_time;?>
                                          </td>

                                          <td>
                                             <?php
$end_time = date("H:i:s", strtotime($val->end_time));
		echo @$end_time;

		?>
                                          </td>

                                          <td class="checklist">
                                           <a href="<?php echo base_url() . 'event/viewChecklist/' . $val->id; ?>" >Checklist</a>
                                          </td>

                                          <td><?php if ($val->status == 1) {echo 'Active';} else {echo 'Inactive';}?></td>

                                          <td><a href="<?php echo base_url() . 'event/editevent/' . $val->id; ?>" class= "md-edit"></a>
                                          <a href="<?php echo base_url() . 'event/deleteevent/' . $val->id; ?>" onclick="return confirm('Are you sure you want to delete this user ?');" class="md-delete" ></a>
                                          </td>

                                        </tr>
                                     <?php }?>
                                     <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php $this->load->view('backend/admin/layouts/footer');?>
