<?php $this->load->view('backend/admin/layouts/header');?>

 <div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3><?php echo @$checklist_name[0]['checklist_name']; ?> Users List</h3>
                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <th>Status</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php if (!empty($checklistUsers)) {
	?>
                                        <?php $i = 1;foreach ($checklistUsers as $val) {
		?>
                                        <tr>
                                          <td><?php echo $i++ ?></td>

                                          <td><?php echo @$val['first_name']; ?></td>
                                          <td><?php echo @$val['last_name']; ?></td>
                                          <td><?php echo @$val['email']; ?></td>
                                          <td>
                                          <?php
if (@$val['status'] == 1) {
			echo 'Accepted';
		}

		?>
                                          </td>



                                        </tr>
                                     <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
