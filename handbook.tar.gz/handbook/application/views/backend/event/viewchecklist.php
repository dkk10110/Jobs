<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <?php $event_id = @$event_name[0]['id'];?>
                            <div class="panel-heading"><h3><?php echo @$event_name[0]['event_name']; ?></h3>

                            <a href="<?php echo base_url(); ?>event/addchecklist/<?php echo $event_id; ?>"  class="btn btn-default" style="float: right; margin-top: -40px;">Add Checklist</a>

                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Checklist Name</th>
                                            <th>Checklist Description</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php if (!empty($query)) {
	?>
                                        <?php $i = 1;foreach ($query as $val) {

		?>
                                        <tr>
                                          <td><?php echo $i++ ?></td>

                                         <td class="evtname"><a href="<?php echo base_url() . 'event/checklistSelectedUsers/' . $val->id . '/' . $event_id ?>"><?php echo @$val->checklist_name; ?></a>
                                         </td>

                                          <td><?php if (empty($val->checklist_description)) {echo "";} else {echo $val->checklist_description;}
		;?></td>


                                          <td>
                                          <a href="<?php echo base_url() . 'event/checklistedit/' . $val->id . '/' . $event_id ?>" class= "md-edit"></a>
                                          <a href="<?php echo base_url() . 'event/checklistdelete/' . $val->id . '/' . $event_id ?>" onclick="return confirm('Are you sure you want to delete this user ?');"  class="md-delete"></a>
                                          </td>


                                        </tr>
                                     <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php $this->load->view('backend/admin/layouts/footer');?>
