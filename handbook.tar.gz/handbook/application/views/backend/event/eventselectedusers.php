<?php $this->load->view('backend/admin/layouts/header');?>

 <div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3><?php echo @$event_name[0]['event_name']; ?></h3>
                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <!-- <th>Rating</th> -->
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Note</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php if (!empty($selected_users)) {
	?>

                                        <?php $i = 1;foreach ($selected_users as $users) {
		?>


                                        <tr>
                                          <td><?php echo $i++ ?></td>
                                          <td><?php echo @$users['first_name']; ?></td>
                                          <td><?php echo @$users['last_name']; ?></td>

                                          <!-- <td>
                                          <?php if (@$users['status'] == 1) {?>
                                          <a href="<?php echo base_url() . 'user/userRating/' . @$users['id'] . '/' . @$users['event_id']; ?>">
                                          Rating</a>
                                          <?php }?>
                                          </td> -->

                                          <td><?php echo @$users['email']; ?></td>

                                          <td>
                                          <?php
if (@$users['status'] == 0) {
			echo 'Awaiting';
		} else if (@$users['status'] == 1) {
			echo 'Accepted';
		} else {
			echo 'Rejected';
		}

		?>

                                          </td>
                                          <td><?php echo @$users['note']; ?></td>




                                        </tr>
                                     <?php }?>
                                     <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



<?php $this->load->view('backend/admin/layouts/footer');?>
