<?php $this->load->view('backend/admin/layouts/header');?>


<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Change Password</div>

                    <div class="panel-body">
                    <form class="form-horizontal create_user" action="<?=site_url('user/Updatepassword')?>" method="post" enctype = "multipart/form-data">
                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>

                       <span style="color: red; margin-left:10px;   color: #3498DB;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('sucess'); ?></span>
                       <div class="col-sm-12">
                        <div class="form-group">
                            <label>New Password</label>
                           <input type="hidden" name= "id" value = "<?php echo $id; ?>" class="form-control">

                            <input type="password" name= "newpass" class="form-control" placeholder="Enter new password" required>
                        </div>
                       </div>
                       <div class="col-sm-12">
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="confirmpass" class="form-control" placeholder="Enter Confirm Password" required>
                        </div>
                        </div>

                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Update" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
