<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Create User</div>
                    <div class="panel-body">
                    <form class="form-horizontal create_user" action="<?=site_url('user/createuser')?>" method="post" enctype = "multipart/form-data">
                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name= "first_name" class="form-control" maxlength="25" placeholder="Enter First Name" required>
                        </div>
                       </div>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" maxlength="25" class="form-control" placeholder="Enter Last Name" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" pattern=".{6,}" title="Six or more characters" class="form-control" placeholder="Enter Password" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" name="country" class="form-control" maxlength="25" placeholder="Enter Country" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" name="city" class="form-control" maxlength="25" placeholder="Enter City" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>State</label>
                            <input type="text" name="state" class="form-control" maxlength="25" placeholder="Enter state" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Address</label>

                            <textarea class= "form-control" name="address" placeholder="Enter Address" required></textarea>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Country Code</label>
                            <input type="text" name="country_phone_code" maxlength="10" class="form-control" placeholder="Enter Country Code" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" maxlength="15" pattern="[789][0-9]{9}" title="Please enter valid phone number" class="form-control" placeholder="Enter Phone" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Profile Image</label>
                            <input type="file" name="profile_img"  size="20" accept="image/*" />
                        </div>
                        </div>

                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
