<?php $this->load->view('backend/admin/layouts/header');?>



<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">

                    <div class="panel-body">
                    <form class="form-horizontal create_user" action="<?=site_url('user/createuserRatung/' . $user_id . '/' . $event_id)?>" method="post" enctype = "multipart/form-data">

                      <input type="hidden" name="event_id" value= "<?php echo $event_id; ?>">
                      <input type="hidden" name="user_id"  value="<?php echo $user_id; ?>">

                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>
                       <?php foreach ($userDetail as $users) {?>
                       <div class="col-sm-2">
                        <div class="form-group">

                         <?php $imguri = 'https://s3.amazonaws.com/handbook_albums/users_images/' . $users['profile_img'];?>
                         <img src="<?php echo $imguri; ?>" width='60px' height='60px' class="imgp">
                        </div>
                        </div>

                        <div class="col-sm-10">
                        <div class="col-sm-12">
                        <div class="form-group">
                        <label>First Name:</label>
                          <?php echo @$users['first_name']; ?>
                        </div>
                        </div>

                        <div class="col-sm-12">
                        <div class="form-group">
                        <label>Email:</label>
                          <?php echo @$users['email']; ?>
                        </div>
                        </div>
                        <?php }?>

                        <div class="col-sm-12">
                        <div class="form-group">
                        <?php if (@$getratingValue[0]['rating']) {?>
                        <?php for ($x = 1; $x <= $getratingValue[0]['rating']; $x++) {?>

                           <?php echo '<span class="fa fa-star checked"></span>' ?>

                          <?php }?>

						<?php } else {?>

						<select id="example" name= "rating">
							  <option value=""></option>
							  <option value="1">1</option>
							  <option value="2">2</option>
							  <option value="3">3</option>
							  <option value="4">4</option>
							  <option value="5">5</option>
						</select>

						<?php }?>

                        </div>
                        </div>

                        <div class="col-sm-12">
                        <div class="form-group">
                         <?php if (@$getratingValue[0]['description']) {?>
                         <textarea name="description" rows="10" cols="40"><?php echo @$getratingValue[0]['description'] ?></textarea>
                         <?php } else {?>
                          <textarea name="description" rows="10" cols="40"></textarea>
                         <?php }?>

                        </div>
                        </div>
                        <div class="col-sm-12">
                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary pull-left" value="Submit" />
                        </div>
                        </div>
                        </div>

                        </form>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
