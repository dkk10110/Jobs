<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Create User</div>
                    <div class="panel-body">
                    <?php foreach ($query as $val) {?>
                    <form class="form-horizontal create_user" action="<?=site_url('user/useredit')?>" method="post" enctype = "multipart/form-data">
                         <input type="hidden" name="id" value="<?=!empty($val->id) ? $val->id : ''?>">

                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>

                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Rating</label>
                          <?php $rating_result = $this->db->select('rating')->where('user_id', $val->id)->get('rating')->row('rating'); ?>
                        <select name="rating" id="example" required >
                          <option value=""></option>
                          <?php for($i = 1; $i<=5; $i++) {?>
                          <option value="<?php echo $i; ?>" <?php echo (in_array($i, range(1, $rating_result))) ? 'selected' : '';?> >
                            <?php echo $rating_result; ?>
                          </option>
                          <?php }?>
                        </select>
                        </div>
                       </div>


                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name= "first_name" value="<?php echo @$val->first_name; ?>" class="form-control" placeholder="Enter First Name" required>
                        </div>
                       </div>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" value="<?php echo @$val->last_name; ?>" class="form-control" placeholder="Enter Last Name" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?php echo @$val->email; ?>" class="form-control" placeholder="Enter Email" required>
                        </div>
                        </div>


                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" name="country" value="<?php echo @$val->country; ?>" class="form-control" placeholder="Enter Country" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" name="city" value="<?php echo @$val->city; ?>" class="form-control" placeholder="Enter City" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>State</label>
                            <input type="text" name="state" value="<?php echo @$val->state; ?>" class="form-control" placeholder="Enter state" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Address</label>

                            <textarea class= "form-control" name="address" placeholder="Enter Address" required><?php echo @$val->address; ?></textarea>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Country Code</label>
                            <input type="text" name="country_phone_code" value="<?php echo @$val->country_phone_code; ?>" class="form-control" placeholder="Enter Country Code" required>
                        </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" value="<?php echo @$val->phone; ?>" class="form-control" placeholder="Enter Phone" required>
                        </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Profile Image</label>
                            <input type="file" name="profile_img"  size="20" accept="image/*" />
                        </div>
                        </div>

                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                        <?php }?>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
