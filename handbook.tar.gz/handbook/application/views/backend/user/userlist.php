<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Users List</h3>
                            <a href="<?php echo base_url(); ?>user/addusers" class="btn btn-default" style="float: right; margin-top: -40px;">Add Users</a>
                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>User Image</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Change Password</th>
                                            <th>Email</th>
                                            <th>Rating</th>
                                            <th>Phone</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1;foreach ($query as $val) {
	?>

                                        <tr>
                                          <td><?php echo $i++ ?></td>

                                          <td>
                                          <?php
$imguri = 'https://s3.amazonaws.com/handbook_albums/users_images/' . $val->profile_img;
	$dummyimg = base_url() . 'uploads/user.jpg';
	?>
                                           <?php if ($imguri != '') {?>
                                            <img src="<?php echo $imguri; ?>" width='60px' height='60px'>
                                           <?php } else {?>
                                            <img src="<?php echo $dummyimg; ?>" width='60px' height='60px'>
                                           <?php }?>
                                          </td>
                                          <td><?php if (empty($val->first_name)) {echo "";} else {echo $val->first_name;}
	;?></td>
                                          <td><?php if (empty($val->last_name)) {echo "";} else {echo $val->last_name;}
	;?></td>

                                          <td><a href="<?php echo base_url() . 'user/ChangePassword/' . $val->id; ?>">Change Password</a></td>




                                          <td><?php if (empty($val->email)) {echo "";} else {echo $val->email;}
	;?></td>
                                           <td>
                                           <? $rating_result = $this->db->select('rating')->where('user_id', $val->id)->get('rating')->row('rating');
                                          if (count($rating)) {
                                            $rating = $rating_result;
                                          }else{
                                            $rating = '';
                                          }
                                           ?>


                                           <?php for ($x = 1; $x <= $rating; $x++) {?>

  <?php echo '<span class="fa fa-star checked" style = "font-size: 10px !important;"></span>' ?>

                                             <?php }?>

                                             </td>

                                          <td><?php echo @$val->country_phone_code . '' . @$val->phone; ?></td>



                                          <td>
                                          <form class="form-horizontal create_user" action="<?=site_url('user/enabledisableAccount/'), $val->id?>" method="post">
                                              <input type="hidden" name="status" value="<?php echo $val->status; ?>">
                                                <button type="submit" class="btn-sm btn-<?php echo $val->status == 1 ? 'success' : 'danger' ?>"><?php echo $val->status == 1 ? 'Active' : 'Deactivated' ?></button>
                                            </form>
                                          </td>

                                          <td><a href="<?php echo base_url() . 'user/userupdate/' . $val->id; ?>" class="md-edit"></a>
                                          <a href="<?php echo base_url() . 'user/deleteuser/' . $val->id; ?>" onclick="return confirm('Are you sure you want to delete this user ?');" class="md-delete" ></a>
                                          </td>


                                        </tr>
                                     <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
