<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Handbook</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body bgcolor="#eee">
	<div>
		<p>Dear, <?php echo $name; ?>,</p>
		<p>You have recently requested to reset your password. To select a new password, click on the link below:</p>
			<?php
$var = $url . '?email=' . $email . '&remember_token=' . $remember_token;
// $encode = base64_encode($var);
?>
		<p "><a href="<?php echo $var; ?>">Reset Password</a></p>

		<p>&nbsp;</p>
		<p>Thanks</p>
		<p>Handbook App Team</p>
	</div>
</body>
</html>