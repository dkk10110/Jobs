<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Handbook</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body bgcolor="#eee">
	<div>
		<p>Dear, <?php echo $name; ?>,</p>
		<p>Welcome to the Handbook App.</p>

		<p>&nbsp;</p>
		<p>Thanks</p>
		<p>Handbook App Team</p>
	</div>
</body>
</html>