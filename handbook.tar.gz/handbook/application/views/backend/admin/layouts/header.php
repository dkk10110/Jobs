<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-clearmin.min.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/roboto.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/material-design.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/small-n-flat.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-multiselect.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.timepicker.css" />
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fontawesome-stars.css" />
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">


        <title><?php echo $this->title; ?></title>

    </head>
    <body class="cm-no-transition cm-1-navbar">
        <div id="cm-menu">
            <nav class="cm-navbar cm-navbar-primary handbook-logo">
                <div class="cm-flex"><a href="<?php echo base_url(); ?>admin/dashboard"><img src="<?php echo base_url(); ?>assets/img/logo-big.svg.png" alt="Logo" width="200" height="50" /> Handbook</a></div>
                <div class="btn btn-primary md-menu-white" data-toggle="cm-menu"></div>
            </nav>
            <div id="cm-menu-content">
                <div id="cm-menu-items-wrapper">
                    <div id="cm-menu-scroller">
                         <?php $url = $this->uri->segment(2);?>

                        <ul class="cm-menu-items">
                            <?php if ($url == 'dashboard') {?>
                            <li class="active"><a href="<?php echo base_url(); ?>admin/dashboard" class="sf-dashboard">Dashboard</a></li>
                            <?php } else {?>
                            <li><a href="<?php echo base_url(); ?>admin/dashboard" class="sf-dashboard">Dashboard</a></li>
                            <?php }?>

                            <?php if ($url == 'userlist' || $url == 'addusers' || $url == 'userupdate') {?>
                            <li class="active"><a href="<?php echo base_url(); ?>user/userlist" class="sf-user-male">Users</a></li>
                            <?php } else {?>
                            <li><a href="<?php echo base_url(); ?>user/userlist" class="sf-user-male">Users</a></li>
                            <?php }?>


                            <?php if ($url == 'eventlist' || $url == 'addevent' || $url == 'eventSelectedUsers' || $url == 'viewChecklist' || $url == 'addchecklist' || $url == 'checklistSelectedUsers' || $url == 'checklistedit') {?>
                            <li class="active"><a href="<?php echo base_url(); ?>event/eventlist" class="sf-disc-vinyl">Events</a></li>
                            <?php } else {?>
                            <li><a href="<?php echo base_url(); ?>event/eventlist" class="sf-disc-vinyl">Events</a></li>
                            <?php }?>


                            <?php if ($url == 'notification') {?>
                            <li class="active"><a href="<?php echo base_url(); ?>admin/notification" class="sf-light-bulb">Notification</a></li>
                            <?php } else {?>
                            <li><a href="<?php echo base_url(); ?>admin/notification" class="sf-light-bulb">Notification</a></li>
                            <?php }?>


                            <?php if ($url == 'pdflist') {?>
                            <li class="active"><a href="<?php echo base_url(); ?>admin/pdflist" class="sf-file-pdf">Uploadpdf</a></li>
                            <?php } else {?>
                            <li><a href="<?php echo base_url(); ?>admin/pdflist" class="sf-file-pdf">Uploadpdf</a></li>
                            <?php }?>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <header id="cm-header">
            <nav class="cm-navbar cm-navbar-primary">
                <div class="btn btn-primary md-menu-white hidden-md hidden-lg" data-toggle="cm-menu"></div>
                <div class="cm-flex">
                    <h1><?php if (@$this->dashboard_title) {
	echo @$this->dashboard_title;
}
?></h1>
                    <form id="cm-search" action="index.html" method="get">
                        <input type="search" name="q" autocomplete="off" placeholder="Search...">
                    </form>
                </div>

               <div class="dropdown pull-right">
                    <button class="btn btn-primary md-notifications-white" data-toggle="dropdown">
                    <?php if (count(getNotificationAlert()) > 0) {?>
                     <span class="label label-danger"><?php echo count(getNotificationAlert()); ?></span>
                     <?php }?>
                     </button>

                     <?php if (count(getNotificationAlert()) > 0) {?>
                    <div class="popover cm-popover bottom">
                        <div class="arrow"></div>
                        <div class="popover-content noti">
                            <div class="list-group">
                                <a href="#" class="list-group-item">
                                    <?php $notifications = getNotificationCountkist();?>
                                    <?php foreach ($notifications as $notification) {?>
                                    <h4 class="list-group-item-heading">
                                        <!-- <i class="fa fa-fw fa-warning"></i> <?php echo $notification['notification_type']; ?> -->
                                    </h4>
                                    <p class="list-group-item-text sf-light-bulb">
                                    <?php if ($notification['checklist_name'] == '') {?>
                                      <?php echo $notification['first_name'] . ' ' . ($notification['status'] == 0 ? 'Awaiting' : $notification['status'] == 1 ? 'Accepted' : $notification['status'] == 2 ? 'Rejected' : 'Upcomming') . ' ' . $notification['event_name'] . ' Event'; ?>

                                      <?php } else {?>
                                      <?php echo $notification['first_name'] . ' ' . ($notification['status'] == 0 ? 'Awaiting' : $notification['status'] == 1 ? 'Accepted' : 'Rejected') . ' ' . $notification['checklist_name'] . ' Checklist'; ?>
                                      <?php }?>
                                    </p>
                                    <?php }?>
                                </a>
                            </div>
                            <div style="padding:10px"><a class="btn btn-success btn-block notification" href="<?php echo base_url() . 'admin/notification' ?>">Show me more...</a></div>
                        </div>
                    </div>
                    <?php } else {?>

                    <div class="popover cm-popover bottom">
                        <div class="arrow"></div>
                        <div class="popover-content noti">
                            <div class="list-group">
                                <a href="#" class="list-group-item">
                                    <h4 class="list-group-item-heading">
                                      Notification Not Found
                                    </h4>
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php }?>

                </div>

                <div class="dropdown pull-right">
                    <button class="btn btn-primary md-account-circle-white" data-toggle="dropdown"></button>
                    <ul class="dropdown-menu">
                        <li class="disabled text-center">
                            <a style="cursor:default;"><strong><?php echo $this->session->userdata('name'); ?></strong></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-cog"></i> Settings</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/logout/"><i class="fa fa-fw fa-sign-out"></i> Sign out</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
