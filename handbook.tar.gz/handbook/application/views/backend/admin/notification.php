<?php $this->load->view('backend/admin/layouts/header');?>

 <div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div><h3 class="panel-heading">Notification List</h3>

                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Notification Type</th>
                                            <th>Event Name</th>
                                            <th>User Name</th>
                                            <th>Checklist Name</th>
                                            <th>Status</th>
                                            <th>Note</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php if (!empty($query)) {
	?>
                                        <?php $i = 1;foreach ($query as $val) {

		?>
                                        <tr>
                                          <td class="tdcss"><?php echo $i++ ?></td>


                                          <td class="tdcss"><?php echo @$val['notification_type']; ?></td>
                                          <td class="tdcss"><?php echo @$val['event_name']; ?></td>
                                          <td class="tdcss"><?php echo @$val['first_name']; ?></td>
                                          <td class="tdcss"><?php echo @$val['checklist_name']; ?></td>
                                          <td class="tdcss">
                                            <?php
if (@$val['status'] == 0) {
			echo 'Awaiting';
		} else if (@$val['status'] == 1) {
			echo 'Accepted';
		} else {
			echo 'Rejected';
		}
		?>

                                          </td>
                                          <td class="tdcss"><?php echo @$val['note']; ?></td>
                                        </tr>
                                     <?php }?>
                                     <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




<?php $this->load->view('backend/admin/layouts/footer');?>
