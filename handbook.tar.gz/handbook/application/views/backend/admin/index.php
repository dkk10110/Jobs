  <?php $this->load->view('backend/admin/layouts/header');?>

        <div id="global">
            <div class="container-fluid cm-container-white">
                <h2 style="margin-top:0;">Welcome to Dashboard !</h2>

            </div>
            <div class="container-fluid dashboard_main">
            <!-- <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
                        <a href="<?php echo base_url(); ?>admin/dashboard" class="panel panel-default thumbnail cm-thumbnail">
                            <div class="panel-body text-center" style="min-height: 168px;">
                                <span class="svg-48">
                                    <img src="<?php echo base_url(); ?>assets/img/sf/dashboard.svg" alt="dashboard">
                                </span>
                                <h4>Dashboard</h4>

                            </div>
                        </a>
                    </div> -->
                        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
                        <a href="<?php echo base_url(); ?>user/userlist" class="panel panel-default thumbnail cm-thumbnail">
                            <div class="panel-body text-center" style="min-height: 168px;">
                                <span class="svg-48">
                                    <img src="<?php echo base_url(); ?>assets/img/sf/user-male.svg" alt="dashboard">
                                </span>
                                <h4>Users (<?php echo @$countUser->count; ?>)</h4>

                            </div>
                        </a>
                    </div>

                        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
                        <a href="<?php echo base_url(); ?>event/eventlist" class="panel panel-default thumbnail cm-thumbnail">
                            <div class="panel-body text-center" style="min-height: 168px;">
                                <span class="svg-48">
                                    <img src="<?php echo base_url(); ?>assets/img/sf/disc-vinyl.svg" alt="dashboard">
                                </span>
                                <h4>Events (<?php echo @$eventCount->count; ?>)</h4>

                            </div>
                        </a>
                    </div>
             </div>

            </div>
         </div>


<?php $this->load->view('backend/admin/layouts/footer');?>
