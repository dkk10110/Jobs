<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-heading">Upload Pdf</div>
                    <div class="panel-body">
                    <form class="form-horizontal create_user" action="<?=site_url('admin/createpdf')?>" method="post" enctype = "multipart/form-data">
                       <span style="color: red; margin-left:10px;   color: #ff0000;    left: 0;    position: absolute;    text-align: center;    top: -15px;    width: 100%;"><?php echo $this->session->flashdata('error'); ?></span>
                       <div class="col-sm-6">
                        <div class="form-group">
                            <label>Pdf Title</label>
                            <input type="text" name= "pdf_title" class="form-control" placeholder="Enter First Name" required>
                        </div>
                       </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            <label>Handbook Pdf</label>
                            <input type="file" name="pdf_file"  size="20" accept="application/pdf" required />
                        </div>
                        </div>

                        <div class="form-group text-right" style="margin-top:20px">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
