<?php $this->load->view('backend/admin/layouts/header');?>

<div id="global">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Pdf List</h3>
                            <a href="<?php echo base_url(); ?>admin/uploadpdf" class="btn btn-default" style="float: right; margin-top: -40px;">Upload pdf</a>
                            </div>
                            <div class="panel-body table_data">

                                <table class="table table-striped table-bordered" style="margin-bottom:0" id="myTable">

                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Pdf Title</th>
                                            <td>Download Pdf</td>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1;foreach ($query as $val) {
	?>

                                        <tr>
                                          <td><?php echo $i++ ?></td>
                                          <td><?php echo $val['pdf_title']; ?></td>

                                          <td>
                                          <?php
$pdfurl = 'https://s3.amazonaws.com/handbook_albums/pdf/' . $val['pdf_file'];
	?>
                                           <a href="<?php echo $pdfurl; ?>" target="_blank">View pdf</a>
                                          </td>

                                          <td>
                                          <a href="<?php echo base_url() . 'admin/deletepdf/' . $val['id']; ?>" onclick="return confirm('Are you sure you want to delete this file ?');" class="md-delete" ></a>
                                          </td>


                                        </tr>
                                     <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $this->load->view('backend/admin/layouts/footer');?>
