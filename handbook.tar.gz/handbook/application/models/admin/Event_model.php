<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);

class Event_model extends CI_Model {

	function __construct() {
		parent::__construct();
		$this->key = $this->config->config['api']['key'];
	}

	// public function getEventlist($where = NULL) {

	// 	$this->db->select('id, event_name, event_album, event_description, event_date, end_event_date ,start_time, end_time, status');
	// 	$this->db->from('hb_event');
	// 	if ($where) {
	// 		$this->db->where($where);
	// 	}
	// 	$query = $this->db->get();

	// 	if ($query->num_rows() > 0):
	// 		return $query->result();
	// 	endif;

	// }

	public function getEventlist() {

		return $this->db->query(' select id, event_name, event_album, event_description, event_date, end_event_date, start_time, end_time, status from hb_event order by id desc')->result();
	}

	public function getUserlist() {

		return $this->db->query('select id, first_name from hb_users where status = 1')->result();
	}

	public function getUserslist($where = NULL) {

		$this->db->select('id');
		$this->db->from('hb_users');
		if ($where) {
			$this->db->where($where);
		}
		$query = $this->db->get();

		if ($query->num_rows() > 0):
			return $query->result_array();
		endif;
	}

	public function checkevents($start_time, $end_time) {

		return $this->db->query("select * from hb_event where (start_time BETWEEN '" . $start_time . "' and '" . $end_time . "') OR (end_time BETWEEN '" . $start_time . "' and '" . $end_time . "')")->result();
	}

	public function getEventname($id) {
		return $this->db->query("select id, event_name from hb_event where id = '" . $id . "'")->result_array();
	}

	function eventInsert($data) {
		$this->db->insert('hb_event', $data);
		$insert_id = $this->db->insert_id();

		return $insert_id;
	}

	function EventIdensert($insert_id) {

		return $this->db->query('insert into hb_notification(event_id, status, notification_type)values(' . $insert_id . ', 3, "upcomming event")');
	}

	public function insertEventImage($insert_id, $img_new_name) {

		$image_data = array('event_album' => $img_new_name);
		$this->db->where('id', $insert_id);
		$this->db->update('event', $image_data);
		return 'ok';
	}

	public function eventuserData($value) {
		$this->db->insert('hb_users_event', $value);
		$insert_id = $this->db->insert_id();

		return $insert_id;
	}

	function viewEvent($id) {
		$this->db->select("id, event_name, event_description, event_album ,event_date, end_event_date, DATE_FORMAT(start_time, '%H:%i') as st_time, DATE_FORMAT(end_time, '%H:%i') as ed_time");
		$this->db->from('hb_event');
		$this->db->where('hb_event.id', $id);
		return $this->db->get()->result();
	}

	function getSelecttdUser($id) {
		return $this->db->query('select selected_users_id from hb_users_event where event_id = "' . $id . '" ')->result_array();
	}

	function deleteEvent($id) {
		$this->db->where('id', $id);
		$this->db->delete('hb_event');
	}

	function updateEvent($data) {

		$this->db->where('id', $data['id']);
		$this->db->update('hb_event', $data);

		$affected_rows = $this->db->affected_rows();

		$get_img = $this->db->get_where('event', array('id' => $data['id']))->result();
		$image_name = $get_img[0]->event_album;
		if (count($_FILES) == 0) {
			if (count($affected_rows == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		} else {
			$image = $_FILES['event_album']['tmp_name'];
			$userfile_name = $_FILES['event_album']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['event_album']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $data['id'] . '.' . $userfile_extn[1];
			//aws
			// Simple PUT:
			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			$extension = pathinfo($img_new_name, PATHINFO_EXTENSION);
			$extensions_type = ['gif', 'jpg', 'png', 'jpeg'];

			if (in_array($extension, $extensions_type)) {

				if (S3::putObject($input, $bucket, 'events_images/' . $uri, S3::ACL_PUBLIC_READ)) {
				} else {
					return false;
				}

			} else {

				if (S3::putObject($input, $bucket, 'events_video/' . $uri, S3::ACL_PUBLIC_READ)) {
				} else {
					return false;
				}

			}

			$image_data = array('event_album' => $img_new_name);
			$this->db->where('id', $data['id']);
			$this->db->update('event', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		}
	}

	public function checklistInsert($data) {
		$this->db->insert('hb_checklist', $data);
	}

	public function getChecklist($id) {

		return $this->db->query("select id, checklist_name, checklist_description from hb_checklist where event_id = '" . $id . "'")->result();
	}

	public function deleteChecklist($id) {
		$this->db->where('id', $id);
		$this->db->delete('hb_checklist');
	}

	public function getchecklistdata($id) {
		$this->db->select("id, checklist_name, checklist_description");
		$this->db->from('hb_checklist');
		$this->db->where('hb_checklist.id', $id);
		return $this->db->get()->result();
	}

	public function updateChecklist($data) {
		$this->db->where('id', $data['id']);
		$this->db->update('hb_checklist', $data);
	}

	public function getEventselectedUsers($id) {
		return $this->db->query("select hb_users.id ,hb_users.first_name, hb_users.last_name, hb_users.email, eventusers.event_id,  eventusers.status, eventusers.note
		from hb_users_event as eventusers
		LEFT JOIN hb_users
		ON  eventusers.selected_users_id = hb_users.id
		where event_id = '" . $id . "'
		GROUP BY eventusers.selected_users_id")->result_array();
	}

	public function getuserDetail($user_id) {

		return $this->db->query('select first_name, email, profile_img from hb_users where id = "' . $user_id . '" ')->result_array();
	}

	public function deleteselectedUsersEvnt($id) {

		$this->db->where('event_id', $id);
		$this->db->delete('hb_users_event');
	}

	public function eventcount() {
		return $this->db->query("select count('*') as count FROM `hb_event`")->row();
	}

	public function getChecklistname($id) {
		return $this->db->query("select id, checklist_name from hb_checklist where id = '" . $id . "'")->result_array();
	}

	public function getchecklistUserid($id) {
		return $this->db->query("select user_id, checklist_id, status from hb_users_checklist where checklist_id = '" . $id . "'")->result_array();
	}

	public function getchecklistbookUsers($id, $user_id, $checklist_id) {
		return $this->db->query("select hb_users.first_name, hb_users.last_name, hb_users.email, checklistusers.status
			from hb_users_checklist as checklistusers
			LEFT JOIN hb_users
			ON  checklistusers.user_id = hb_users.id
			where user_id = '" . $user_id . "' AND checklist_id = '" . $checklist_id . "' AND checklistusers.status = 1 ")->result_array();

	}

	public function getNotificationDetail() {
		return $this->db->query("select  hb_event.event_name, hb_users.first_name,  hb_checklist.checklist_name, hb_notification.status, hb_notification.note, hb_notification.notification_type
			from  hb_notification
			LEFT JOIN  hb_event
			ON   hb_event.id = hb_notification.event_id
			LEFT JOIN  hb_users
			ON  hb_users.id = hb_notification.user_id
			LEFT JOIN  hb_checklist
			ON  hb_checklist.id = hb_notification.checklist_id")->result_array();
	}

	public function getNotificationcount() {
		return $this->db->query("select *  from hb_notification where is_delete = 1")->result_array();
	}

	public function getNotificationcountList() {

		return $this->db->query("select  hb_event.event_name, hb_users.first_name,  hb_checklist.checklist_name, hb_notification.status, hb_notification.note, hb_notification.notification_type
			from  hb_notification
			LEFT JOIN  hb_event
			ON   hb_event.id = hb_notification.event_id
			LEFT JOIN  hb_users
			ON  hb_users.id = hb_notification.user_id
			LEFT JOIN  hb_checklist
			ON  hb_checklist.id = hb_notification.checklist_id ORDER BY hb_notification.notification_type DESC LIMIT 0, 3"
		)->result_array();
	}

	public function UpdateNotificationStatus() {
		return $this->db->query('UPDATE hb_notification  SET is_delete = 0');
	}

	public function getUser($users_id) {
		return $this->db->get_where('users', array('id' => $users_id))->result();
	}

}
