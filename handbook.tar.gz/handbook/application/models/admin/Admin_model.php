<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	public function checkAdminLogin($email, $password) {

		$this->db->where('email', $email);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$query = $this->db->get('admin');
		$result = $query->result();
		return $result;
	}

	public function Insertpdf($data) {

		$this->db->insert('hb_pdf', $data);
		$insert_id = $this->db->insert_id();

		if (count($_FILES) == 0) {
			if (count($insert_id == 1)) {
				return $insert_id;
			} else {
				return 0;
			}
		} else {
			$image = $_FILES['pdf_file']['tmp_name'];
			$userfile_name = $_FILES['pdf_file']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['pdf_file']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = 'Handbook' . '_' . $random . $insert_id . '.' . $userfile_extn[1];

			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			if (S3::putObject($input, $bucket, 'pdf/' . $uri, S3::ACL_PUBLIC_READ)) {
			} else {
				return false;
			}
			$image_data = array('pdf_file' => $img_new_name);
			$this->db->where('id', $insert_id);
			$this->db->update('hb_pdf', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return $insert_id;
			} else {
				return 0;
			}
		}
	}

	public function getPdflist() {

		return $this->db->query('select id, pdf_title, pdf_file from hb_pdf')->result_array();
	}

	public function deletpdf($id) {

		$this->db->where('id', $id);
		$this->db->delete('hb_pdf');
	}

}
