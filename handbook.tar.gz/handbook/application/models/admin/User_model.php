<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	public function getUserlist($where = NULL) {

		$this->db->select('id, first_name ,last_name, email	,country, city, country_phone_code, phone, profile_img, device_type, device_token, status');
		$this->db->from('hb_users');
		if ($where) {
			$this->db->where($where);
		}
		$query = $this->db->get();

		if ($query->num_rows() > 0):
			return $query->result();
		endif;
	}

	public function checkInsEmail($email) {
		$this->db->select('*');
		$this->db->from('hb_users');
		$this->db->where('email', $email);
		$query = $this->db->get();
		return $query->result_array();
	}

	public function usercount() {
		return $this->db->query("select count('*') as count FROM `hb_users`")->row();
	}

	function formInsert($data) {
		$this->db->insert('hb_users', $data);
		$insert_id = $this->db->insert_id();
		if (count($_FILES) == 0) {
			if (count($insert_id == 1)) {
				return $insert_id;
			} else {
				return 0;
			}
		} else {
			$image = $_FILES['profile_img']['tmp_name'];
			$userfile_name = $_FILES['profile_img']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['profile_img']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $insert_id . '.' . $userfile_extn[1];
			//aws
			// Simple PUT:
			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			if (S3::putObject($input, $bucket, 'users_images/' . $uri, S3::ACL_PUBLIC_READ)) {
			} else {
				return false;
			}
			//move_uploaded_file($image, "uploads/users_image/" . $img_new_name);
			$image_data = array('profile_img' => $img_new_name);
			$this->db->where('id', $insert_id);
			$this->db->update('users', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return $insert_id;
			} else {
				return 0;
			}
		}

	}

	function updateUser($data) {
		$this->db->where('id', $data['id']);
		$this->db->update('hb_users', $data);
		$affected_rows = $this->db->affected_rows();

		$get_img = $this->db->get_where('users', array('id' => $data['id']))->result();
		$image_name = $get_img[0]->profile_img;
		if (count($_FILES) == 0) {
			if (count($affected_rows == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		} else {
			$image = $_FILES['profile_img']['tmp_name'];
			$userfile_name = $_FILES['profile_img']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['profile_img']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $data['id'] . '.' . $userfile_extn[1];
			//aws
			// Simple PUT:
			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			if (S3::putObject($input, $bucket, 'users_images/' . $uri, S3::ACL_PUBLIC_READ)) {
			} else {
				return false;
			}

			$image_data = array('profile_img' => $img_new_name);
			$this->db->where('id', $data['id']);
			$this->db->update('users', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		}

	}

	function viewUser($id) {
		$this->db->select('id, first_name, last_name,email,password,country,city,state,address,phone,country_phone_code, profile_img');
		$this->db->from('hb_users');
		$this->db->where('hb_users.id', $id);
		return $this->db->get()->result();
	}

	function deleteUser($id) {
		$this->db->where('id', $id);
		$this->db->delete('hb_users');
	}

	public function checkCount($where, $table = 'hb_users') {
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->get()->num_rows();

	}

	public function disableUuseraccount($id, $status) {
		if ($status == 1) {
			return $this->db->query('update hb_users SET status= 0 WHERE  id = "' . $id . '"');
		} else {
			return $this->db->query('update hb_users SET status= 1 WHERE  id = "' . $id . '"');

		}
	}

	public function changePassword($data) {
		return $this->db->query('update hb_users SET password=  "' . $data['confirmpass'] . '" where id= "' . $data['id'] . '"');
	}

	public function CheckratingUser($user_id, $event_id) {

		return $this->db->query('select event_id, user_id from hb_rating where event_id = "' . $event_id . '" and user_id = "' . $user_id . '"')->row();
	}

	public function UpdateUserData($user_id, $event_id, $rating, $des) {
		return $this->db->query('update hb_rating set rating = "' . $rating . '" , description = "' . $des . '" where event_id = "' . $event_id . '" and user_id = "' . $user_id . '" ');
	}

	public function insertRatingValus($data) {
		$this->db->insert('hb_rating', $data);
		$insert_id = $this->db->insert_id();

	}

	public function getValueRating($user_id, $event_id) {
		return $this->db->query('select rating, description from hb_rating where user_id = "' . $user_id . '" and event_id = "' . $event_id . '"')->result_array();
	}

}
