<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

Class Auth_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	//index model
	public function index() {
		echo 'This is index model';
	}

	//check email availability
	public function checkEmailAvailable($email) {
		$this->db->where('email', $email);
		$this->db->where('status', 1);
		$this->db->where('is_delete', 1);
		$query = $this->db->get('users');
		$result = $query->result();
		if ($result) {
			return $result;
		}
	}

	//check password
	public function checkPassword($email, $password) {
		$this->db->where('email', $email);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$this->db->where('is_delete', 1);
		$query = $this->db->get('users');
		$result = $query->result();
		if (count($result)) {
			return $result;
		}
	}

	//get user id
	public function getUserId($email) {
		$user_id = $this->db->get_where('users', array('email' => $email))->result();
		return $user_id[0]->id;
	}

	//update device token and device type
	public function updateToken($device_type = '', $device_token = '', $user_id = '') {
		$data = array(
			'device_type' => $device_type,
			'device_token' => $device_token,
		);
		$this->db->where('id', $user_id);
		$this->db->update('users', $data);
		$afected_row = $this->db->affected_rows();
		return $afected_row;
	}

	//get user data
	public function getUserData($user_id) {
		$this->db->select('id, first_name, last_name, email, country, city, state, phone, country_phone_code, address');
		$this->db->where('id', $user_id);
		$query = $this->db->get('users');
		$result = $query->result_array();
		return $result;
	}

	public function getUserRating($user_id) {
		$get_ratings = $this->db->get_where('hb_rating', array('user_id' => $user_id))->result_array();
		$total = '';
		$counttotal = '';
		foreach ($get_ratings as $key => $ratings) {
			$total += $ratings['rating'];
			$counttotal += count($ratings['rating']);
			$avg = $total / $counttotal;
		}
		return @$avg;
	}

	//get All User user
	public function getAllUserData($user_id) {
		$this->db->select('id, first_name');
		$this->db->where('id !=', $user_id);
		$query = $this->db->get('users');
		$result = $query->result_array();
		return $result;
	}

	//get event data
	public function getEventData($userId) {
		return $this->db->query('select  hevnt.id, hevnt.event_id, hevnt.status ,event_name, event_description , event_album, event_date, start_time, end_time from hb_users_event as hevnt join  hb_users as  hu on  hu.id = hevnt.selected_users_id join hb_event as he on he.id = hevnt.event_id  where  hevnt.selected_users_id = "' . $userId . '" ')->result_array();

	}

	//get Event Status awating
	public function getEventDatawaiting($userId) {
		return $this->db->query('select  hevnt.event_id, hevnt.status ,event_name, event_description, event_date, start_time, end_time from hb_users_event as hevnt join  hb_users as  hu on  hu.id = hevnt.selected_users_id join hb_event as he on he.id = hevnt.event_id  where  hevnt.selected_users_id = "' . $userId . '"')->result_array();

	}

	//get Event Status Accepted

	public function getEventDataccepted($userId) {

		return $this->db->query('select  hevnt.event_id, hevnt.status ,event_name, event_description, event_date, start_time, end_time from hb_users_event as hevnt join  hb_users as  hu on  hu.id = hevnt.selected_users_id join hb_event as he on he.id = hevnt.event_id  where  hevnt.selected_users_id = "' . $userId . '" and hevnt.status = 1 ')->result_array();

	}

	// Get image url
	public function getImageUrl($type = '', $id = '') {
		$get_img = $this->db->get_where('users', array('id' => $id))->result();
		$img_name = $get_img[0]->profile_img;
		if ($img_name) {
			$bucket = 'handbook_albums';
			$uri = 'users_images/' . $img_name;
			$image_url = 'https://s3.amazonaws.com/' . $bucket . '/' . $uri;
			//$image_url = S3::getAuthenticatedURL($bucket, $uri, 3600);
			//$object = S3::getObject($bucket, $uri);
			//$image_url = base_url() . 'uploads/' . $type . '_image/' . $img_name;
		} else {
			$image_url = base_url() . 'uploads/user.jpg';
		}
		return $image_url;
	}

	//get Pdf url

	public function getpdfUrl() {
		$getPdf = $this->db->query('select * from hb_pdf')->result();
		foreach ($getPdf as $pdf) {
			$pdfuri = '';
			if ($pdf) {
				$pdfuri = 'https://s3.amazonaws.com/handbook_albums/pdf/' . $pdf->pdf_file;
			}
			$pdf_name = $pdf->pdf_file;
			$info = pathinfo($pdf_name);
			$file_name = $info['filename'];

			$pdfData[] = array('id' => $pdf->id, 'pdf_title' => $pdf->pdf_title, 'file_name' => $file_name,
				'pdf_file' => $pdfuri);

		}
		return $pdfData;

	}

	// Get image url
	public function getAllUsersData($user_id) {

		$get_img = $this->db->query('select   hb_users.id, hb_users.first_name, hb_users.profile_img, avg(IFNULL(rating,0)) as rating from hb_users  left join  hb_rating on hb_users.id = hb_rating.user_id where hb_users.id != "' . $user_id . '" group by hb_users.id')->result();
		foreach ($get_img as $imageUrl) {
			$imguri = '';
			if ($imageUrl != '') {
				$imguri = 'https://s3.amazonaws.com/handbook_albums/users_images/' . $imageUrl->profile_img;
			} else {
				$imguri = base_url() . 'uploads/user.jpg';
			}

			$imageData[] = array('id' => $imageUrl->id, 'first_name' => $imageUrl->first_name, 'image_url' => $imguri, 'rating' => $imageUrl->rating);
		}

		return $imageData;
	}

	//Update Profile
	public function editProfile($user_id) {
		$user_id = $this->input->post('id');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$country = $this->input->post('country');
		$city = $this->input->post('city');
		$state = $this->input->post('state');
		$address = $this->input->post('address');
		$phone = $this->input->post('phone');
		$country_phone_code = $this->input->post('country_phone_code');
		$data = array(
			'first_name' => $first_name,
			'last_name' => $last_name,
			'country' => $country,
			'phone' => $phone,
			'city' => $city,
			'state' => $state,
			'address' => $address,
			'country_phone_code' => $country_phone_code,
		);

		$this->db->where('id', $user_id);
		$this->db->update('hb_users', $data);
		$affected_rows = $this->db->affected_rows();

		$get_img = $this->db->get_where('hb_users', array('id' => $user_id))->result();
		@$image_name = $get_img[0]->profile_img;
		if (count($_FILES) == 0) {
			if (count($affected_rows == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		} else {
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$image = $_FILES['profile_img']['tmp_name'];
			$userfile_name = $_FILES['profile_img']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['profile_img']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $user_id . '.' . $userfile_extn[1];
			//aws
			// Simple PUT:
			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			if (S3::putObject($input, $bucket, 'users_images/' . $uri, S3::ACL_PUBLIC_READ)) {
			} else {
				return false;
			}
			$image_data = array('profile_img' => $img_new_name);
			$this->db->where('id', $user_id);
			$this->db->update('users', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return "TRUE";
			} else {
				return "FALSE";
			}
		}
	}

	//get user name
	public function getUserName($id) {
		$user_id = $this->db->get_where('users', array('id' => $id))->result();
		return $user_id[0]->first_name;
	}

	//update remember token for forgot passowrd
	public function updateRememberToken($email, $data) {
		$this->db->where('email', $email);
		$this->db->update('users', $data);
		$afftected_row = $this->db->affected_rows();
		return $afftected_row;
	}

	//check rember token is exits or not
	public function checkToken($email) {
		$check_token = $this->db->select('remember_token')->where('email', $email)->get('users')->row('remember_token');
		return $check_token;
	}

	//reset password by link
	public function resetPassword($email, $remember_token) {
		$data = array('remember_token' => '');
		$this->db->where('email', $email);
		$this->db->where('remember_token', $remember_token);
		$this->db->update('users', $data);
		$afftected_row = $this->db->affected_rows();
		return $afftected_row;

	}

	public function getEventDetaildata($event_id) {

		$data = $this->db->query('select * from hb_event
			where  id  = "' . $event_id . '" ')->row();

		$data1['id'] = $data->id;
		$data1['event_name'] = $data->event_name;
		$data1['event_description'] = $data->event_description;
		$data1['event_album'] = $data->event_album;
		$data1['event_date'] = $data->event_date;
		$data1['end_event_date'] = $data->end_event_date;
		$data1['start_time'] = $data->start_time;
		$data1['end_time'] = $data->end_time;
		$data1['status'] = $data->status;
		$data1['created_date'] = $data->created_date;

		$getchecklist = $this->getEventckklist($data->id);
		$getUsercommentList = $this->getDisplayCommentUsersList($data->id);

		$n = 0;
		$data1['checklist'] = [];
		foreach ($getchecklist as $checklistdata) {
			$data1['checklist'][$n]['id'] = $checklistdata['id'];
			$data1['checklist'][$n]['event_id'] = $checklistdata['event_id'];
			$data1['checklist'][$n]['checklist_name'] = $checklistdata['checklist_name'];
			$data1['checklist'][$n]['checklist_description'] = $checklistdata['checklist_description'];
			$data1['checklist'][$n]['status'] = $checklistdata['status'];

			$n++;
		}

		$m = 0;
		$data1['user'] = [];
		foreach ($getUsercommentList as $userComment) {

			$getuserImage = $this->getImageUrl('users', $userComment['id']);
			$data1['user'][$m]['id'] = $userComment['id'];
			$data1['user'][$m]['first_name'] = $userComment['first_name'];
			$data1['user'][$m]['message'] = $userComment['message'];
			$data1['user'][$m]['date_time'] = $userComment['date_time'];
			$data1['user'][$m]['img_url'] = $getuserImage;

			$m++;

		}

		return $data1;

	}

	public function getEventckklist($event_id) {

		return $this->db->query("select hbuserchlst.id, hbuserchlst.event_id, hbuserchlst.checklist_name, hbuserchlst.checklist_description,  IFNULL(hb_users_checklist.status, '') as status from  hb_checklist as  hbuserchlst
			LEFT JOIN  hb_users_checklist
			ON   hbuserchlst.id  =  hb_users_checklist.checklist_id
			WHERE  hbuserchlst.event_id = ' " . $event_id . "'
			")->result_array();
	}

	public function getAccetpRejectStatus($event_id, $user_id, $status, $note) {

		return $this->db->query('update hb_users_event SET status= "' . $status . '" , note = "' . $note . '" WHERE  event_id = "' . $event_id . '"  AND  selected_users_id = "' . $user_id . '"');
	}

	public function getAccetpRejectNotification($event_id, $user_id, $status, $note) {

		return $this->db->query('insert into hb_notification (event_id, user_id, status, note,  notification_type )VALUES ("' . $event_id . '", "' . $user_id . '", "' . $status . '", "' . $note . '", "event notification" );');
	}

	public function getchecklistbookData($event_id, $checklist_id, $user_id, $status) {
		$checklistData = explode(',', $checklist_id);
		$statusData = explode(',', $status);

		$data = array('event_id' => $event_id, 'checklist_id' => $checklistData, 'status' => $statusData, 'user_id' => $user_id);

		foreach ($checklistData as $key => $checklstid) {
			$evt_id = $data['event_id'];
			$uid = $data['user_id'];
			$status = $data['status'][$key];
			$checkid = $data['checklist_id'][$key];

			$insertArray = array('event_id' => $evt_id, 'user_id' => $uid, 'status' => $status, 'checklist_id' => $checkid);
			$result = $this->selectInsertedcheckist($checklstid);
			if ($result) {
				$statusNew['status'] = $data['status'][$key];
				$this->db->where('checklist_id', $checkid);
				$this->db->update('hb_users_checklist', $statusNew);
			} else {
				$insertdata = $this->db->insert('hb_users_checklist', $insertArray);
			}

		}
		return $insertArray;

	}

	private function selectInsertedcheckist($checklstid) {
		return $this->db->query("select * from hb_users_checklist where checklist_id = " . $checklstid . "")->result_array();
	}

	public function getChecklistBookNotification($event_id, $checklist_id, $user_id, $status) {

		$checklistData = explode(',', $checklist_id);
		$statusData = explode(',', $status);

		$data = array('event_id' => $event_id, 'checklist_id' => $checklistData, 'status' => $statusData, 'user_id' => $user_id, 'notification_type' => 'checklist Book notification');

		foreach ($checklistData as $key => $checklstid) {
			$evt_id = $data['event_id'];
			$uid = $data['user_id'];
			$status = $data['status'][$key];
			$checkid = $data['checklist_id'][$key];
			$notificationType = 'checklist Book notification';

			$insertArray = array('event_id' => $evt_id, 'user_id' => $uid, 'status' => $status, 'checklist_id' => $checkid, 'notification_type' => 'Checklist Book notification');
			$result = $this->selectInsertedcheckistNotification($checklstid);
			if ($result) {
				$statusNew['status'] = $data['status'][$key];
				$this->db->where('checklist_id', $checkid);
				$this->db->update('hb_notification', $statusNew);
			} else {
				$insertdata = $this->db->insert('hb_notification', $insertArray);
			}

		}
		return $insertArray;
	}

	private function selectInsertedcheckistNotification($checklstid) {
		return $this->db->query("select * from hb_notification where checklist_id = " . $checklstid . "")->result_array();
	}

	//get Event comment
	public function getEventcommentData($event_id, $user_id, $message) {
		$datetime = date("Y-m-d h:i:s");
		$data = array('event_id' => $event_id, 'user_id' => $user_id, 'message' => $message, 'date_time' => $datetime);
		$this->db->insert('hb_comments', $data);
		$user_id = $this->db->insert_id();
		if (count($user_id) == 1) {
			return $user_id;
		} else {
			return 0;
		}

	}

	//get Event Display comment array
	public function getDisplayEventComments($event_id) {

		$data = $this->db->query('select * from hb_event
			where  id  = "' . $event_id . '" ')->row();
		$data1['id'] = $data->id;
		$data1['event_name'] = $data->event_name;

		$commentUsersList = $this->getDisplayCommentUsersList($data->id);
		$n = 0;
		$data1['user'] = [];
		foreach ($commentUsersList as $usersList) {
			$getuserImage = $this->getImageUrl('users', $usersList['id']);

			$data1['user'][$n]['id'] = $usersList['id'];
			$data1['user'][$n]['first_name'] = $usersList['first_name'];
			$data1['user'][$n]['message'] = $usersList['message'];
			$data1['user'][$n]['date_time'] = $usersList['date_time'];
			$data1['user'][$n]['img_url'] = $getuserImage;

			$n++;
		}
		return $data1;

	}

	public function getDisplayCommentUsersList($event_id) {

		return $this->db->query("select  hbusers.id, hbusers.first_name ,  hb_comments.message , hb_comments.date_time  from  hb_users as  hbusers
			LEFT JOIN  hb_comments
			ON   hbusers.id  =  hb_comments.user_id
			WHERE  hb_comments.event_id = '" . $event_id . "'")->result_array();

	}

	public function getUserAllnotification($user_id) {

		return $this->db->query("select  hb_event.event_name, hb_users.first_name,  hb_checklist.checklist_name , hb_notification.notification_type, hb_notification.status ,hb_notification.created_date
			from  hb_notification
			LEFT JOIN  hb_event
			ON   hb_event.id = hb_notification.event_id
			LEFT JOIN  hb_users
			ON  hb_users.id = hb_notification.user_id
			LEFT JOIN  hb_checklist
			ON  hb_checklist.id = hb_notification.checklist_id WHERE hb_notification.user_id = '" . $user_id . "' ")->result_array();

	}

	//User Logout

	public function getClearDeviceTocken($user_id) {
		return $this->db->query("update hb_users SET device_token = '' where id = '" . $user_id . "' ");
	}

	//old query
	// Insert Users Data.
	public function insertUserData($user_data) {
		$this->db->insert('users', $user_data);
		$user_id = $this->db->insert_id();
		if (count($_FILES) == 0) {
			if (count($user_id == 1)) {
				return $user_id;
			} else {
				return 0;
			}
		} else {
			$image = $_FILES['profile_img']['tmp_name'];
			$userfile_name = $_FILES['profile_img']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['profile_img']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $user_id . '.' . $userfile_extn[1];
			//aws
			// Simple PUT:
			$file = $image;
			$bucket = 'lwp_images';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			if (S3::putObject($input, $bucket, 'users_image/' . $uri, S3::ACL_PUBLIC_READ)) {
			} else {
				return false;
			}
			//move_uploaded_file($image, "uploads/users_image/" . $img_new_name);
			$image_data = array('profile_img' => $img_new_name);
			$this->db->where('id', $user_id);
			$this->db->update('users', $image_data);
			$affected_rows1 = $this->db->affected_rows();
			if (count($affected_rows1 == 1)) {
				return $user_id;
			} else {
				return 0;
			}
		}
	}

	//get country list
	public function getCountryList($country) {
		$this->db->select('id, name, phonecode, iso');
		$query = $this->db->get('countries');
		$result = $query->result();
		return $result;
	}

	//check email availability
	public function checkIdAvailable($id) {
		$this->db->where('id', $id);
		$this->db->where('status', 1);
		$this->db->where('is_delete', 1);
		$query = $this->db->get('users');
		$result = $query->result();
		if ($result) {
			return $result;
		}
	}

	//check password
	public function checkOldPassword($id, $old_password) {
		$this->db->where('id', $id);
		$this->db->where('password', $old_password);
		$this->db->where('status', 1);
		$this->db->where('is_delete', 1);
		$query = $this->db->get('users');
		$result = $query->result();
		if (count($result)) {
			return $result;
		}
	}

	//get user id
	public function getColorCode($user_id) {
		$get_color_id = $this->db->select('color')->where('id', $user_id)->get('users')->row('color');
		$get_code = $this->db->select('color_code')->where('id', $get_color_id)->get('color')->row('color_code');
		return $get_code;
	}

	// Get  church image url
	public function getChurchImageUrl($type = '', $id = '') {
		$get_img = $this->db->get_where('church', array('id' => $id))->result();
		$img_name = $get_img[0]->image;
		if ($img_name) {
			$bucket = 'lwp_images';
			$uri = 'church_image/' . $img_name;
			$image_url = 'https://s3.amazonaws.com/' . $bucket . '/' . $uri;
			//$image_url = S3::getAuthenticatedURL($bucket, $uri, 3600);
			//$image_url = base_url() . 'uploads/' . $type . '_image/' . $img_name;
		} else {
			$image_url = base_url() . 'uploads/church.jpg';
		}
		return $image_url;
	}

	//check bookmark
	public function checkBookmarkStatus($user_id, $church_id) {
		$get_bookmark = $this->db->get_where('bookmark_church', array('user_id' => $user_id, 'church_id' => $church_id))->result();
		if (count($get_bookmark)) {
			foreach ($get_bookmark as $key => $value) {
				if ($value->status == 1) {
					return 1;
				} else {
					return 0;
				}
			}
		} else {
			return 0;
		}
	}

	//get country list
	public function getChurchList($user_id) {
		$this->db->select('church.id, church.church_id, church.name, color.color_code');
		$this->db->from('church');
		$this->db->join('color', 'church.color = color.id', 'left');
		$this->db->order_by('church.id', 'DESC');
		$this->db->where('church.status', 1);
		$query = $this->db->get();
		$result = $query->result();
		$response = [];
		if (count($result)) {
			foreach ($result as $key => $value) {
				$response = $result;
				$response[$key]->bookmark_status = $this->checkBookmarkStatus($user_id, $value->id);
				$response[$key]->churh_img_url = $this->getChurchImageUrl('church', $value->id);
			}
		}
		return $response;
	}

	//check bookmark
	public function checkOnlyBookmarkStatus($user_id, $church_id) {
		$get_bookmark = $this->db->get_where('bookmark_church', array('user_id' => $user_id, 'church_id' => $church_id))->result();
		if (count($get_bookmark)) {
			foreach ($get_bookmark as $key => $value) {
				if ($value->status == 1) {
					return 1;
				} else {
					return 0;
				}
			}
		} else {
			return 0;
		}
	}

	//get country list
	public function getbookmarkChurchList($user_id) {
		$this->db->select('church.id, church.church_id, church.name, color.color_code');
		$this->db->from('church');
		$this->db->join('color', 'church.color = color.id', 'left');
		$this->db->order_by('church.id', 'DESC');
		$this->db->where('church.status', 1);
		$query = $this->db->get();
		$result = $query->result();
		$response = [];
		if (count($result)) {
			foreach ($result as $key => $value) {
				$bookmark_status = $this->checkOnlyBookmarkStatus($user_id, $value->id);

				if ($bookmark_status == 1) {
					$response[$key]['id'] = $value->id;
					$response[$key]['church_id'] = $value->church_id;
					$response[$key]['name'] = $value->name;
					$response[$key]['color_code'] = $value->color_code;
					$response[$key]['bookmark_status'] = 1;
					$response[$key]['churh_img_url'] = $this->getChurchImageUrl('church', $value->id);
				}
			}
		}
		return $response;
	}

	//update device token and device type
	public function insertBookmark($user_id, $church_id, $status) {
		$avail_bookmark = $this->db->get_where('bookmark_church', array('user_id' => $user_id, 'church_id' => $church_id))->result();

		if (count($avail_bookmark) == 0) {
			$data = array(
				'user_id' => $user_id,
				'church_id' => $church_id,
				'status' => $status,
			);
			$this->db->insert('bookmark_church', $data);
			$insert_id = $this->db->insert_id();
			return $insert_id;
		} else {
			$data = array(
				'user_id' => $user_id,
				'church_id' => $church_id,
				'status' => $status,
			);
			$this->db->where('user_id', $user_id);
			$this->db->where('church_id', $church_id);
			$this->db->update('bookmark_church', $data);
			$afected_row = $this->db->affected_rows();
			return $afected_row;
		}
	}

	//update password
	public function updatePassword($email, $data) {
		$this->db->where('email', $email);
		$this->db->update('users', $data);
		$afftected_row = $this->db->affected_rows();
		return $afftected_row;
	}

	//change password
	public function changePassword($id, $data) {
		$this->db->where('id', $id);
		$this->db->update('users', $data);
		$afftected_row = $this->db->affected_rows();
		return $afftected_row;
	}

	//delete user account   ==  soft delete
	public function deleteUserAccount($user_id) {
		$data = array('is_delete' => 0);
		$this->db->where('id', $user_id);
		$this->db->update('users', $data);
		$affected_rows = $this->db->affected_rows();
		return $affected_rows;
	}

	// Get  church category image url
	public function getChurchCategoryImageUrl($type = '', $id = '') {
		$get_img = $this->db->get_where('church_category', array('id' => $id))->result();
		$img_name = $get_img[0]->image;
		$img_url = base_url() . 'uploads/' . $type . '_image/' . $img_name;
		if ($img_name) {
			// if (file_exists(base_url() . 'uploads/' . $type . '_image/' . $img_name)) {
			$bucket = 'lwp_images';
			$uri = 'category_image/' . $img_name;
			$image_url = 'https://s3.amazonaws.com/' . $bucket . '/' . $uri;
			//$image_url = S3::getAuthenticatedURL($bucket, $uri, 3600);
			//$image_url = base_url() . 'uploads/' . $type . '_image/' . $img_name;
			// }
		} else {
			$image_url = base_url() . 'uploads/church.jpg';
		}
		return $image_url;
	}

	public function getPaystackDetails() {
		$data = $this->db->select('id, test_secret_key, test_public_key, live_secret_key, live_public_key, paystack_test_mode')
			->get('setting')
			->result_array();
		$result = $data[0];
		if ($result['paystack_test_mode'] == 1) {
			$paysatck_key['sk'] = $result['test_secret_key'];
			$paysatck_key['pk'] = $result['test_public_key'];
		} else {
			$paysatck_key['sk'] = $result['live_secret_key'];
			$paysatck_key['pk'] = $result['live_public_key'];
		}
		return $paysatck_key;
	}

	//get church category list
	public function getChurchCategoryList($church_id) {
		$this->db->select('id, church_id, category_name, recipient_code, subaccount_code');
		$this->db->where('church_id', $church_id);
		$this->db->where('is_delete', 1);
		$this->db->where('status', 1);
		$query = $this->db->get('church_category');
		$result = $query->result();
		$response = [];
		$response = $result;
		if (count($result)) {
			foreach ($result as $key => $value) {
				$category_id = $value->id;
				$response[$key]->category_image_url = $this->getChurchCategoryImageUrl('category', $category_id);
			}
		}
		$data['paysatck_details'] = $this->getPaystackDetails();
		$data['category_info'] = $response;
		return $data;
	}

	//get country list
	public function getChurchListSearch($user_id, $id_name) {
		$this->db->select('church.id, church.church_id, church.name, color.color_code');
		$this->db->from('church');
		$this->db->join('color', 'church.color = color.id', 'left');
		$this->db->order_by('church.id', 'DESC');
		$this->db->like('church.church_id', $id_name, 'before');
		$this->db->or_like('church.name', $id_name, 'both');
		$this->db->where('church.status', 1);
		$query = $this->db->get();
		$result = $query->result();
		$response = [];
		if (count($result)) {
			foreach ($result as $key => $value) {
				$response = $result;
				$response[$key]->bookmark_status = $this->checkBookmarkStatus($user_id, $value->id);
				$response[$key]->churh_img_url = $this->getChurchImageUrl('church', $value->id);
			}
		}
		return $response;
	}

	//Get paysatck customer id
	public function getPaystackCustomerId($user_id) {
		$id = $this->db->select('customer_id')->where('user_id', $user_id)->limit(1)->get('pay_amount')->row('customer_id');
		return $id;
	}

	//Get secure pin
	public function getSecurePin($user_id) {
		$id = $this->db->select('secure_pin')->where('id', $user_id)->get('users')->row('secure_pin');
		return $id;
	}

	// Update Secure pin
	public function updateSecurePin($user_id, $secure_pin) {
		$data = array('secure_pin' => $secure_pin);
		$this->db->where('id', $user_id);
		$this->db->update('users', $data);
		$affected_rows = $this->db->affected_rows();
		return $affected_rows;
	}

}