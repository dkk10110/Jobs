<?php
interface CrudModelInterface {
	public function create();
	public function load1();
	public function update();
	public function delete();
}
?>