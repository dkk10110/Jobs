<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public $title = 'Users';
	public $dashboard_title = false;

	function __construct() {
		parent::__construct();
		$this->load->model("admin/User_model");
		$this->load->library('session');
		$this->load->model("admin/Event_model");

	}

	//Create Users
	public function addusers() {

		$this->dashboard_title = 'Users';
		$this->load->view('backend/user/createuser');
	}

	public function createuser() {

		$email = $this->input->post('email');
		$result = $this->User_model->checkInsEmail($email);
		if (!empty($result)) {
			$this->session->set_flashdata('error', 'Email alrady exists.');
			redirect('user/addusers');
		} else {

			$is_save = TRUE;

			if ($this->input->post()) {
				$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'email' => $this->input->post('email'),
					'password' => sha1($this->input->post('password')),
					'country' => $this->input->post('country'),
					'city' => $this->input->post('city'),
					'state' => $this->input->post('state'),
					'address' => $this->input->post('address'),
					'country_phone_code' => $this->input->post('country_phone_code'),
					'phone' => $this->input->post('phone'),
				);
			}

			$insert_id = $this->User_model->formInsert($data);
			if (count($insert_id)) {
				$this->session->set_flashdata('esucess', 'User Added Successfully');
				redirect('user/userlist');
			} else {
				$this->session->set_flashdata('error', 'Something went wrong');
				redirect('user/addusers');
			}
		}
	}

	public function userupdate($id = NULL) {
		$this->dashboard_title = 'Users';
		$data['query'] = $this->User_model->viewUser($id);
		$this->load->view('backend/user/updateuser', $data);

	}

	public function useredit() {

		$id = $this->input->post('id');
		$email = $this->input->post('email');
		$result = $this->User_model->checkInsEmail($email);

		if ($this->User_model->checkCount(['id !=' => $id, 'email' => $email], 'hb_users')) {
			$this->session->set_flashdata('error', 'Email alrady exists.');
			redirect('user/userupdate/' . $id);
		}

		$data['id'] = $id;
		$data['first_name'] = $this->input->post('first_name');
		$data['last_name'] = $this->input->post('last_name');
		$data['country'] = $this->input->post('country');
		$data['city'] = $this->input->post('city');
		$data['state'] = $this->input->post('state');
		$data['address'] = $this->input->post('address');
		$data['country_phone_code'] = $this->input->post('country_phone_code');
		$data['phone'] = $this->input->post('phone');

		$rating = $this->input->post('rating');

		$user_info = $this->User_model->updateUser($data);

		$check_rating = $this->db->select('id')->where('user_id', $id)->get('rating')->row('id');
		if (count($check_rating)) {
			$rating_data = array('rating' => $rating);
			$this->db->where('user_id', $id);
			$this->db->update('rating', $rating_data);
		} else {
			$rating_data = array('rating' => $rating, 'user_id' => $id);
			$this->db->where('user_id', $id);
			$this->db->insert('rating', $rating_data);
		}
		// $this->db->insert()
		$this->session->set_flashdata('esucess', 'User Updated Successfully');
		redirect('user/userlist');

	}

	public function deleteuser($id = NULL) {
		$this->User_model->deleteUser($id);
		redirect('user/userlist');
	}

	//Get Userlist
	public function userlist() {
		$this->dashboard_title = 'Users';
		$data['query'] = $this->User_model->getUserlist();
		$this->load->view('backend/user/userlist', $data);
	}

	//Activate Deactive user account
	public function enabledisableAccount($id) {
		$status = $this->input->post('status');
		$data['query'] = $this->User_model->disableUuseraccount($id, $status);
		redirect('user/userlist');
	}

	//Change Password
	public function ChangePassword($id) {
		$this->dashboard_title = 'Change Password';
		$data['id'] = $id;
		$this->load->view('backend/user/changepassword', $data);

	}

	public function Updatepassword() {

		$data['id'] = $this->input->post('id');
		$data['newpass'] = sha1($this->input->post('newpass'));
		$data['confirmpass'] = sha1($this->input->post('confirmpass'));
		if ($data['confirmpass'] == $data['newpass']) {
			$result = $this->User_model->changePassword($data);
		} else {
			$this->session->set_flashdata('error', 'New Password and confirm password does not match with each other');
			redirect(site_url('user/ChangePassword/' . $data['id']));
		}
		$this->session->set_flashdata('sucess', 'Password changed successfully !!');
		redirect(site_url('user/ChangePassword/' . $data['id']));

	}

	public function userRating($user_id, $event_id) {
		$data['user_id'] = $user_id;
		$data['event_id'] = $event_id;
		$data['userDetail'] = $this->Event_model->getuserDetail($user_id);
		$data['getratingValue'] = $this->User_model->getValueRating($user_id, $event_id);
		$this->load->view('backend/user/userating', $data);
	}

	public function createuserRatung($user_id, $event_id) {
		$rating = $this->input->post('rating');
		$des = $this->input->post('description');

		$data = array('user_id' => $user_id, 'event_id' => $event_id, 'rating' => $rating, 'description' => $des);
		$checkUserrating = $this->User_model->CheckratingUser($user_id, $event_id);

		if ($checkUserrating) {
			$updateUserData = $this->User_model->UpdateUserData($user_id, $event_id, $rating, $des);
		} else {
			$insert_id = $this->User_model->insertRatingValus($data);
		}
		redirect('event/eventSelectedUsers/' . $event_id);

	}

}
