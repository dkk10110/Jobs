<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}
header('Content-Type: application/json');

class Auth extends MY_Controller {
	function __construct() {
		parent::__construct();
	}
	//index
	public function index() {
		echo 'This is index function.';
	}

	//User sign in
	public function userLogin() {
		$email = $this->input->post('email');
		$password = sha1($this->input->post('password'));
		$device_type = $this->input->post('device_type');
		$device_token = $this->input->post('device_token');
		if (!empty($email) && !empty($password)) {
			$check_email_available = $this->auth_model->checkEmailAvailable($email);
			if (count($check_email_available) > 0) {
				$checkPassword = $this->auth_model->checkPassword($email, $password);
				if (count($checkPassword) > 0) {
					$user_id = $this->auth_model->getUserId($email);
					$this->auth_model->updateToken($device_type, $device_token, $user_id);
					$getData = $this->auth_model->getUserData($user_id);
					$image_url = $this->auth_model->getImageUrl('users', $user_id);
					// $secure_pin = $this->auth_model->getSecurePin($user_id);
					$data = $getData[0];
					$data['image_url'] = $image_url;
					// $data['secure_pin'] = $secure_pin;
					$code = '200';
					$message = LOGIN_SUCCESS;
					$this->success($code, $message, $data);
				} else {
					$code = '300';
					$message = LOGIN_FAIL;
					$this->error($code, $message);
				}
			} else {
				$code = '203';
				$message = EMAIL_NOT_EXISTS;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//Update device type and token
	public function updateToken() {
		$user_id = $this->input->post('user_id');
		$device_type = $this->input->post('device_type');
		$device_token = $this->input->post('device_token');
		if (!empty($user_id) && !empty($device_type) && !empty($device_token)) {
			$afected_row = $this->auth_model->updateToken($device_type, $device_token, $user_id);
			if (count($afected_row) > 0) {
				$code = '200';
				$message = UPDATE_SUCCESS;
				$this->success($code, $message);
			} else {
				$code = '201';
				$message = UPDATE_ERROR;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//Get user profile
	public function getProfile() {
		$user_id = $this->input->post('user_id');
		if (!empty($user_id)) {
			$getData = $this->auth_model->getUserData($user_id);
			foreach ($getData as $getsData) {
				$id = $getsData['id'];
				$firstname = $getsData['first_name'];
				$lastname = $getsData['last_name'];
				$email = $getsData['email'];
				$country = $getsData['country'];
				$city = $getsData['city'];
				$state = $getsData['state'];
				$phone = $getsData['phone'];
				$country_phone_code = $getsData['country_phone_code'];
				$address = $getsData['address'];
			}

			$image_url = $this->auth_model->getImageUrl('users', $user_id);
			$get_rating = $this->auth_model->getUserRating($user_id);
			if ($get_rating == null) {
				$rating = 0;
			} else {
				$rating = $this->auth_model->getUserRating($user_id);
			}

			if (count($getData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$getData[0]['image_url'] = $image_url;
				$data = $getData[0];
				$data = array('id' => $id, 'first_name' => $firstname, 'last_name' => $lastname, 'email' => $email, 'country' => $country, 'city' => $city, 'state' => $state, 'phone' => $phone, 'country_phone_code' => $country_phone_code, 'address' => $address, 'rating' => $rating, 'image_url' => $image_url);
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//Get Events
	public function getEvents() {
		$userId = $this->input->post('user_id');

		if (!empty($userId)) {
			$geteventData = $this->auth_model->getEventData($userId);
			if (count($geteventData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				// $getData[0]['image_url'] = $image_url;
				$data = $geteventData;

				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Update Profile
	public function updateProfile() {
		$user_id = $this->input->post('id');
		if (!empty($user_id)) {
			$update_info = $this->auth_model->editProfile($user_id);
			$getData = $this->auth_model->getUserData($user_id);
			$image_url = $this->auth_model->getImageUrl('hb_users', $user_id);
			if ($update_info == "TRUE") {
				$code = '200';
				$message = UPDATE_SUCCESS;
				$getData[0]['image_url'] = $image_url;
				$data = $getData[0];
				$this->success($code, $message, $data);
			} else {
				$code = '201';
				$message = UPDATE_ERROR;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//forgot password
	public function forgotPassword() {
		$email = $this->input->post('email');
		if (!empty($email)) {
			$check_avail = $this->auth_model->checkEmailAvailable($email);
			if (count($check_avail) > 0) {
				$user_id = $this->auth_model->getUserId($email);
				$name = $this->auth_model->getUserName($user_id);

				$random = random_string('alnum', 10);
				$token = sha1($random);
				$data = array('remember_token' => $token);

				$rememberToken = $this->auth_model->updateRememberToken($email, $data);

				$subject = "Reset password link from Handbook App";
				$headers = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: admin@gmail.com' . "\r\n";
				base_url() . 'MailConfirm/confirmation_mail/?user_id=' . base64_encode($user_id . '&email=' . $email);
				$mailer_username = config_item('mailer_username');
				$mailer_name = config_item('mailer_name');

				$data = array(
					'name' => $name,
					'email' => $email,
					'remember_token' => $token,
					'url' => base_url() . 'MailConfirm/resetPassword/',
				);

				$this->email->from($mailer_username, $mailer_name);
				$this->email->set_mailtype("html");
				$this->email->to($email); // replace it with receiver mail id
				$this->email->subject($subject); // replace it with relevant subject
				$body = $this->load->view('backend/mail/send_email.php', $data, TRUE);
				$this->email->message($body);
				$sent_mail = $this->email->send();
				if ($sent_mail) {
					$code = '200';
					$message = PASS_SUCCESS;
					$this->success($code, $message);
				} else {
					$code = '201';
					$message = UPDATE_ERROR;
					$this->error($code, $message);
				}
			} else {
				$code = '300';
				$message = EMAIL_NOT_EXISTS;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	public function getAllUsers() {

		$userId = $this->input->post('user_id');

		if (!empty($userId)) {
			$getAlluserData = $this->auth_model->getAllUsersData($userId);

			if (count($getAlluserData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				//$getAlluserData['image_url'] = $image_url;
				$data = $getAlluserData;

				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	public function getEventdetail() {

		$event_id = $this->input->post('event_id');

		if (!empty($event_id)) {
			$getEventdetail = $this->auth_model->getEventDetaildata($event_id);

			if (count($getEventdetail) > 0) {
				$code = '200';
				$message = REC_FOUND;
				//$getAlluserData['image_url'] = $image_url;
				$data = $getEventdetail;

				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	public function getEventacceptReject() {

		$event_id = $this->input->post('event_id');
		$user_id = $this->input->post('user_id');
		$status = $this->input->post('status');
		$note = $this->input->post('note');
		if (!empty($user_id)) {
			$getEventacceptReject = $this->auth_model->getAccetpRejectStatus($event_id, $user_id, $status, $note);
			$gerAcceptRejectNotification = $this->auth_model->getAccetpRejectNotification($event_id, $user_id, $status, $note);
			if ($status == 1) {
				$code = '200';
				$message = 'Accepted';
				//$data = $getEventacceptReject;
				$payload = [
					'from_id' => 'admin',
					'to_id' => $user_id,
					'type' => 'Accepted Event',
					'date' => date('Y-m-d H:i:s'),
					'message' => 'You have accepted the event',
				];
				$iosPayload = [
					'alert' => 'New event assign.',
					'message' => 'New event assign.',
					'type' => 'Event',
					'sound' => 'default',
					'badge' => 1,
				];

				$this->pushNotif($user_id, $payload, $iosPayload);
				$this->success($code, $message);

			} else if ($status == 2) {
				$code = '200';
				$message = 'Declined';
				//$data = $getEventacceptReject;
				$payload = [
					'from_id' => 'admin',
					'to_id' => $user_id,
					'type' => 'Rejected Event',
					'date' => date('Y-m-d H:i:s'),
					'message' => 'You have Rejected the event',
				];
				$iosPayload = [
					'alert' => 'New event assign.',
					'message' => 'New event assign.',
					'type' => 'Event',
					'sound' => 'default',
					'badge' => 1,
				];

				$this->pushNotif($user_id, $payload, $iosPayload);
				$this->success($code, $message);

			} else {

				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	public function getChecklistBook() {

		$event_id = $this->input->post('event_id');
		$checklist_id = $this->input->post('checklist_id');
		$user_id = $this->input->post('user_id');
		$status = $this->input->post('status');
		if (!empty($user_id)) {
			$getchecklistdata = $this->auth_model->getchecklistbookData($event_id, $checklist_id, $user_id, $status);
			$getChecklistNotification = $this->auth_model->getChecklistBookNotification($event_id, $checklist_id, $user_id, $status);
			if (count($getchecklistdata) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$data = $getchecklistdata;
				$this->success($code, $message);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get event comment
	public function addEventcomments() {
		$event_id = $this->input->post('event_id');
		$user_id = $this->input->post('user_id');
		$message = $this->input->post('message');
		if (!empty($event_id)) {
			$getEventcommentData = $this->auth_model->getEventcommentData($event_id, $user_id, $message);
			if (count($getEventcommentData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$data = $getEventcommentData;
				$this->success($code, $message);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//Get Display event Comment
	public function getDisplayeventComment() {
		$event_id = $this->input->post('event_id');
		if (!empty($event_id)) {
			$displayEventcomment = $this->auth_model->getDisplayEventComments($event_id);
			if (count($displayEventcomment) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$data = $displayEventcomment;
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get User Notification Details
	public function getUsersAllnotification() {

		$user_id = $this->input->post('user_id');
		if (!empty($user_id)) {
			$getUserNotification = $this->auth_model->getUserAllnotification($user_id);
			//$Notificationdes = $this->auth_model->getNotificationDescription($user_id);

			if (count($getUserNotification) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$data = $getUserNotification;
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get User Logout
	public function getUserLogout() {
		$user_id = $this->input->post('user_id');
		$getuserLogout = $this->auth_model->getClearDeviceTocken($user_id);
		if (!empty($user_id)) {
			if ($getuserLogout) {
				$code = '200';
				$message = 'Logout Successfully';
				$this->success($code, $message);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get Events Status Awaiting
	public function getUpcommingEvents() {
		$userId = $this->input->post('user_id');

		if (!empty($userId)) {
			$geteventData = $this->auth_model->getEventDatawaiting($userId);
			if (count($geteventData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				// $getData[0]['image_url'] = $image_url;
				$data = $geteventData;

				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get Events Status Accepted
	public function getMyevents() {
		$userId = $this->input->post('user_id');

		if (!empty($userId)) {
			$geteventData = $this->auth_model->getEventDataccepted($userId);
			if (count($geteventData) > 0) {
				$code = '200';
				$message = REC_FOUND;
				// $getData[0]['image_url'] = $image_url;
				$data = $geteventData;

				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error($code, $message);
			}
		} else {

			$code = '400' . $selected_users_id;
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//get Pdf

	public function gethandbookPdf() {

		$pdf_Url = $this->auth_model->getpdfUrl();

		if (count($pdf_Url) > 0) {
			$code = '200';
			$message = REC_FOUND;
			$data = $pdf_Url;
			$this->success($code, $message, $data);
		} else {
			$code = '300';
			$message = REC_NOT_FOUND;
			$this->error($code, $message);
		}

	}

	//old
	//Country List
	public function countryList() {
		$country = '';
		$data = $this->users_model->getCountryList($country);
		if (count($data) > 0) {
			$code = '200';
			$message = REC_FOUND;
			$this->success($code, $message, $data);
		} else {
			$code = '300';
			$message = REC_NOT_FOUND;
			$this->error(300, REC_NOT_FOUND);
		}
	}

	//Get all church list
	public function churchList() {
		$user_id = $this->input->post('user_id');
		if (!empty($user_id)) {
			$data = $this->users_model->getChurchList($user_id);
			if (count($data) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error(300, REC_NOT_FOUND);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get all church list
	public function bookmarkChurchList() {
		$user_id = $this->input->post('user_id');
		if (!empty($user_id)) {
			$data = $this->users_model->getbookmarkChurchList($user_id);
			$response = [];
			foreach ($data as $key => $value) {
				$response[] = $value;
			}
			if (count($data) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$this->success($code, $message, $response);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error(300, REC_NOT_FOUND);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//bookmark church
	public function bookmarkChurch() {
		$user_id = $this->input->post('user_id');
		$church_id = $this->input->post('church_id');
		$status = $this->input->post('status');
		$church_id_all = explode(',', $church_id);
		if (!empty($user_id) && !empty($church_id) && $status != '') {
			foreach ($church_id_all as $value) {
				$afected_row = $this->users_model->insertBookmark($user_id, $value, $status);
			}
			if (count($afected_row) > 0) {
				$code = '200';
				$message = CHURCH_BOOKMARK_SUCCESS;
				$this->success($code, $message);
			} else {
				$code = '201';
				$message = CHURCH_BOOKMARK_ERROR;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

	//Reset Password
	public function changePassword() {
		$user_id = $this->input->post('user_id');
		$old_password = sha1($this->input->post('old_password'));
		$new_password = sha1($this->input->post('new_password'));
		if (!empty($user_id) && !empty($old_password) && !empty($new_password)) {
			$check_avail = $this->users_model->checkIdAvailable($user_id);
			if (count($check_avail) > 0) {
				$check_old_password = $this->users_model->checkOldPassword($user_id, $old_password);
				if (count($check_old_password) > 0) {
					$data = array('password' => $new_password);
					$this->users_model->changePassword($user_id, $data);
					$code = '200';
					$message = CHANGE_PASS_SUCCESS;
					$this->error($code, $message);
				} else {
					$code = '304';
					$message = INVALID_OLD_PASS;
					$this->error($code, $message);
				}
			} else {
				$code = '300';
				$message = ID_NOT_EXISTS;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	// Delete account
	public function deleteAccount() {
		$user_id = $this->input->post('user_id');
		if (!empty($user_id)) {
			$deleted_id = $this->users_model->deleteUserAccount($user_id);
			if (count($deleted_id) > 0) {
				$code = '200';
				$message = DELETE_SUCCESS;
				echo codeSuccess($code, $message);
			} else {
				$code = '201';
				$message = DELETE_ERROR;
				echo codeError($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			echo codeError($code, $message);
		}

	}

	//Get all church category list
	public function churchCategoryList() {
		$church_id = $this->input->post('church_id');
		if (!empty($church_id)) {
			$data = $this->users_model->getChurchCategoryList($church_id);
			if (count($data) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error(300, REC_NOT_FOUND);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//Get all church list
	public function churchListSearch() {
		$id_name = $this->input->post('id_name');
		$user_id = $this->input->post('user_id');
		if (!empty($user_id) && !empty($id_name)) {
			$data = $this->users_model->getChurchListSearch($user_id, $id_name);
			if (count($data) > 0) {
				$code = '200';
				$message = REC_FOUND;
				$this->success($code, $message, $data);
			} else {
				$code = '300';
				$message = REC_NOT_FOUND;
				$this->error(300, REC_NOT_FOUND);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}

	}

	//insert secure pin for user
	public function insertSucerePin() {
		$user_id = $this->input->post('user_id');
		$secure_pin = $this->input->post('secure_pin');
		if (!empty($user_id) && !empty($secure_pin)) {
			$affected_rows = $this->users_model->updateSecurePin($user_id, $secure_pin);
			if (count($affected_rows) > 0) {
				$code = '200';
				$message = PIN_UPDATED;
				$this->success($code, $message);
			} else {
				$code = '201';
				$message = PIN_NOT_UPDATE;
				$this->error($code, $message);
			}
		} else {
			$code = '400';
			$message = BAD_REQUEST;
			$this->error($code, $message);
		}
	}

}
