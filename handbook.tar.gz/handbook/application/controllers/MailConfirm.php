<?php if (!defined('BASEPATH')) {exit('No direct script access allowed');}
// header('Content-Type: application/json');

class MailConfirm extends CI_Controller {
	function __construct() {
		parent::__construct();
	}
	public function index() {
		echo "this is index function";
	}

	public function resetPassword() {
		$email = $this->input->get('email');
		$check_token = $this->auth_model->checkToken($email);
		if ($check_token) {
			$this->load->view('backend/mail/reset_password.php');
		} else {
			$this->load->view('backend/mail/expire_link.php');
		}
	}

	//update password
	public function updatePassword() {
		$email = $this->input->get('email');
		$new_password = $this->input->post('password_confirm');
		$remember_token = $this->input->get('remember_token');
		if (!empty($email) && !empty($remember_token)) {
			$afftected_row = $this->auth_model->resetPassword($email, $remember_token, $new_password);
			if (count($afftected_row)) {
				$this->load->view('backend/mail/thank_you.php');
			} else {
				$this->load->view('backend/mail/alert.php');
			}
		} else {
			echo 'Somthing wrong.';
		}

	}

	//Category List
	public function confirmation_mail() {
		$user_id = $this->input->get('user_id');
		$email = $this->input->get('email');
		$password = $this->input->get('password');
		$affected_rows = $this->auth_model->confirmMail($user_id, $email);
		if ($affected_rows == 0) {
			$this->load->view('backend/mail/alert.php');
		} else {
			$this->load->view('backend/mail/thank_you.php');
		}
	}

}