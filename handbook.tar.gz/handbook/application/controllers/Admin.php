<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public $title = 'Dashboard';
	public $dashboard_title = false;

	function __construct() {
		parent::__construct();
		$this->load->model("admin/Admin_model");
		$this->load->model("admin/User_model");
		$this->load->model("admin/Event_model");
		$this->load->library('session');

	}

	public function index() {
		if ($this->session->userdata('login_type')) {
			redirect(base_url() . 'admin/dashboard', 'refresh');
		}

		redirect(base_url() . 'admin/login', 'refresh');
	}

	//Login
	public function login() {
		if ($this->session->userdata('login_type')) {
			redirect(base_url() . 'admin/dashboard', 'refresh');
		}

		$this->load->view('backend/admin/login');

	}

	//checkLogin
	public function checkLogin() {

		$email = $this->input->post('email');
		$password = sha1($this->input->post('password'));
		$check_login = $this->Admin_model->checkAdminLogin($email, $password);
		if (count($check_login) == 1) {
			$this->session->set_userdata('admin_login', '1');
			$this->session->set_userdata('login_user_id', $check_login[0]->id);
			$this->session->set_userdata('name', $check_login[0]->name);
			$this->session->set_userdata('login_type', 'admin');
			redirect(base_url() . 'admin/dashboard', 'refresh');
		} else {
			$this->session->set_flashdata('invalid_login', 'Invalid Email/Password.');
			redirect(base_url() . 'admin/login', 'refresh');

		}
	}

	//Dashboard
	public function dashboard() {

		if ($this->session->userdata('login_type') != 'admin') {
			redirect(base_url() . 'admin/login', 'refresh');
		} else {
			$this->dashboard_title = 'Dashboard';
			$user_count['countUser'] = $this->User_model->usercount();
			$user_count['eventCount'] = $this->Event_model->eventcount();
			$this->load->view('backend/admin/index', $user_count);
		}
	}

	//Logout
	public function logout() {
		$this->session->sess_destroy();
		redirect(base_url() . 'admin/login', 'refresh');
	}

	//notification

	public function notification() {
		$data['query'] = $this->Event_model->getNotificationDetail();
		$updateStatus = $this->Event_model->UpdateNotificationStatus();
		$this->dashboard_title = 'Notification';
		$this->load->view('backend/admin/notification', $data);

	}

	//upload pdf
	public function uploadpdf() {
		$this->dashboard_title = 'Uploadpdf';
		$this->load->view('backend/pdf/upload');
	}

	//pdf list

	public function pdflist() {
		$this->dashboard_title = 'Uploadpdf';
		$data['query'] = $this->Admin_model->getPdflist();
		$this->load->view('backend/pdf/pdflist', $data);

	}

	//create pdf
	public function createpdf() {
		if ($this->input->post()) {

			$data = array('pdf_title' => $this->input->post('pdf_title'));

			$insert_id = $this->Admin_model->Insertpdf($data);
			if (count($insert_id)) {
				$this->session->set_flashdata('esucess', 'pdf Uploaded Successfully');
				redirect('admin/pdflist');
			} else {
				$this->session->set_flashdata('error', 'Something went wrong');
				redirect('admin/uploadpdf');
			}

		}
	}

	public function deletepdf($id) {

		$this->Admin_model->deletpdf($id);
		redirect('admin/pdflist');
	}

}
