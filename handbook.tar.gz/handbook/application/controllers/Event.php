<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Event extends SA_Controller {

	public $title = 'Events';
	public $dashboard_title = false;

	function __construct() {
		parent::__construct();
		$this->load->model("admin/Event_model");
		$this->load->library('session');

	}

	//Create Event
	public function addevent() {

		$this->dashboard_title = 'Events';
		$user['query'] = $this->Event_model->getUserlist();
		$this->load->view('backend/event/addevent', $user);
	}

	public function createEvent() {

		if ($this->input->post()) {

			$event_name = $this->input->post('event_name');
			$event_description = $this->input->post('event_description');
			$selected_users_id = $this->input->post('selected_users_id');
			$event_date = $this->input->post('event_date');

			$end_event_date = $this->input->post('end_event_date');

			$newevent_date = date("Y-m-d", strtotime($event_date));

			$end_date = date("Y-m-d", strtotime($end_event_date));

			$start_time = $newevent_date . ' ' . $this->input->post('start_time');
			$end_time = $end_date . ' ' . $this->input->post('end_time');

			$image = $_FILES['event_album']['tmp_name'];
			$userfile_name = $_FILES['event_album']['name'];
			$userfile_extn = explode(".", strtolower($_FILES['event_album']['name']));
			$random = random_string('alnum', 10);
			$img_new_name = $random . $insert_id . '.' . $userfile_extn[1];

			$file = $image;
			$bucket = 'handbook_albums';
			$uri = $img_new_name;
			$input = S3::inputFile($file);
			$extension = pathinfo($img_new_name, PATHINFO_EXTENSION);

			$data = array('event_name' => $event_name, 'event_description' => $event_description, 'event_date' => $event_date, 'end_event_date' => $end_event_date, 'start_time' => $start_time, 'end_time' => $end_time);

			$insert_id = $this->Event_model->eventInsert($data);

			$UpcommingEventNotification = $this->Event_model->EventIdensert($insert_id);

			foreach ($selected_users_id as $users_id) {
				$value = array('event_id' => $insert_id, 'selected_users_id' => $users_id);
				$insert_data = $this->Event_model->eventuserData($value);
				$payload = [
					'from_id' => 'admin',
					'to_id' => $users_id,
					'type' => 'Admin assign event',
					'date' => date('Y-m-d H:i:s'),
					'message' => 'You have receive new event.',
				];
				$iosPayload = [
					'alert' => 'New event assign.',
					'message' => 'New event assign.',
					'type' => 'Event',
					'sound' => 'default',
					'badge' => 1,
				];

				$this->pushNotif($users_id, $payload, $iosPayload);

			}

			$extensions_type = ['gif', 'jpg', 'png', 'jpeg'];
			if (in_array($extension, $extensions_type)) {
				S3::putObject($input, $bucket, 'events_images/' . $uri, S3::ACL_PUBLIC_READ);
			} else {
				S3::putObject($input, $bucket, 'events_video/' . $uri, S3::ACL_PUBLIC_READ);
			}
			$msg = $this->Event_model->insertEventImage($insert_id, $img_new_name);

			if ($msg == 'ok') {
				$this->session->set_flashdata('success', 'Event Added Successfully');
				redirect('event/eventlist');
			} else {
				$this->session->set_flashdata('error', 'Something went wrong');
				redirect('event/addevent');
			}
		}
	}

	public function editevent($id = NULL) {

		$this->dashboard_title = 'Events';
		$data['user'] = $this->Event_model->getUserlist(); //all users for edit

		$data_id['userId'] = $this->Event_model->getUserslist(); ///all user id list

		$data['selectedUser'] = $this->Event_model->getSelecttdUser($id); //event_users

		$data['query'] = $this->Event_model->viewEvent($id);
		$this->load->view('backend/event/editevent', $data);
	}

	public function updateEvent() {

		$id = $this->input->post('id');
		$event_name = $this->input->post('event_name');
		$event_description = $this->input->post('event_description');
		$selected_users_id = $this->input->post('selected_users_id');

		$event_date = $this->input->post('event_date');
		$newevent_date = date("Y-m-d", strtotime($event_date));

		$end_date = $this->input->post('end_event_date');
		$end_event_date = date("Y-m-d", strtotime($end_date));

		$start_time = $newevent_date . ' ' . $this->input->post('start_time');
		$end_time = $end_event_date . ' ' . $this->input->post('end_time');

		$data = array('event_name' => $event_name, 'event_description' => $event_description, 'event_date' => $event_date, 'end_event_date' => $end_date, 'start_time' => $start_time, 'end_time' => $end_time, 'id' => $id);

		// $check_event_date = $this->Event_model->checkevents($start_time, $end_time);
		// if ($check_event_date) {
		// 	$this->session->set_flashdata('error', 'Event Already Booked for this date');
		// 	redirect('event/editevent/' . $id);
		// }
		$event_update = $this->Event_model->updateEvent($data);
		$delete_event = $this->Event_model->deleteselectedUsersEvnt($id);
		foreach ($selected_users_id as $users_id) {
			$value = array('event_id' => $id, 'selected_users_id' => $users_id);
			$insert_data = $this->Event_model->eventuserData($value);

		}
		$this->session->set_flashdata('esucess', 'Event Updated Successfully');
		redirect('event/eventlist');

	}

	public function deleteevent($id = NULL) {
		$this->Event_model->deleteEvent($id);
		redirect('event/eventlist');
	}

	//Get Eventlist
	public function eventlist() {

		$this->dashboard_title = 'Events';
		$data['query'] = $this->Event_model->getEventlist();
		$this->load->view('backend/event/eventlist', $data);
	}

	public function viewChecklist($id = NULL) {

		$this->dashboard_title = 'Events';
		$data['event_name'] = $this->Event_model->getEventname($id);
		$data['query'] = $this->Event_model->getChecklist($id);
		$this->load->view('backend/event/viewchecklist', $data);
	}

	public function addchecklist($id = NULL) {
		$data['id'] = $id;
		$data['event_name'] = $this->Event_model->getEventname($id);
		$this->load->view('backend/event/addchecklist', $data);

	}

	public function createChecklist() {
		if ($this->input->post()) {
			$id = $this->input->post('id');
			$checklistName = $this->input->post('checklist_name');
			$checklistDescription = $this->input->post('checklist_description');
			$created_date = date("Y-m-d h:i:s");
			$data = array('event_id' => $id, 'checklist_name' => $checklistName, 'checklist_description' => $checklistDescription, 'created_date' => $created_date);

			$insert_id = $this->Event_model->checklistInsert($data);
			$this->session->set_flashdata('success', 'CheckList Added Successfully');
			redirect('event/viewChecklist/' . $id);
		}

	}

	public function checklistdelete($id = NULL, $post_id) {

		$this->Event_model->deleteChecklist($id);
		redirect('event/viewChecklist/' . $post_id);
	}

	public function checklistedit($id = NULL) {

		$this->dashboard_title = 'Events';
		$data['query'] = $this->Event_model->getchecklistdata($id);

		$this->load->view('backend/event/editchecklist', $data);
	}

	public function updateChecklist() {

		if ($this->input->post()) {
			$post_id = $this->input->post('postid');
			$id = $this->input->post('id');
			$checklistName = $this->input->post('checklist_name');
			$checklistDescription = $this->input->post('checklist_description');
			$created_date = date("Y-m-d h:i:s");
			$data = array('id' => $id, 'checklist_name' => $checklistName, 'checklist_description' => $checklistDescription, 'created_date' => $created_date);

			$checklist_update = $this->Event_model->updateChecklist($data);
			$this->session->set_flashdata('esucess', 'Checklist Updated Successfully');
			redirect('event/viewChecklist/' . $post_id);

		}
	}

	public function eventSelectedUsers($id) {

		$this->dashboard_title = 'Events';
		$data['event_name'] = $this->Event_model->getEventname($id);
		$data['selected_users'] = $this->Event_model->getEventselectedUsers($id);
		$this->load->view('backend/event/eventselectedusers', $data);

	}

	public function checklistSelectedUsers($id = NULL) {

		$this->dashboard_title = 'Events';
		$checkId = $this->Event_model->getchecklistUserid($id);

		@$user_id = $checkId[0]['user_id'];
		@$checklist_id = $checkId[0]['checklist_id'];

		$data['checklist_name'] = $this->Event_model->getChecklistname($id);
		$data['checklistUsers'] = $this->Event_model->getchecklistbookUsers($id, @$user_id, @$checklist_id);
		$this->load->view('backend/event/checklistselectedusers', $data);

	}

}
