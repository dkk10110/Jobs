<?php

function getNotificationAlert() {

	$CI = get_instance();
	$CI->load->model('Event_model');
	$result = $CI->Event_model->getNotificationcount();
	return $result;

}

function getNotificationCountkist() {

	$CI = get_instance();
	$CI->load->model('Event_model');
	$result = $CI->Event_model->getNotificationcountList();
	return $result;

}
