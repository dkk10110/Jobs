<?php defined('BASEPATH') OR exit('No direct script access allowed.');
/*
Mail details
 */
$config['protocol'] = 'mail';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';

$config['newline'] = "\r\n";
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_port'] = '465';
//$config['smtp_user'] = 'e8d72fbe-a747-4c61-b356-0dd252008332';
//$config['smtp_pass'] = 'e8d72fbe-a747-4c61-b356-0dd252008332';
$config['smtp_user'] = 'testing.handbook@gmail.com';
$config['smtp_pass'] = 'handbook@123@';

$config['smtp_crypto'] = 'tls';
$config['mailer_username'] = 'noreply@loveworldpayonline.com';
$config['mailer_name'] = 'LoveWorld Pay';
